plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.example.tvhome"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.tvhome"
        minSdk = 28 // fire TV Stick läuft mit Fire OS 7/8 (Android 9/11)
        targetSdk = 33
        versionCode = 8
        versionName = "8.0"
    }

    // Fester Schlüssel: damit lassen sich Updates einfach drüber installieren
    signingConfigs {
        create("tobi") {
            storeFile = file("tvhome.keystore")
            storePassword = "tvhome123"
            keyAlias = "tobi"
            keyPassword = "tvhome123"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("tobi")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("tobi")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.tv:tv-material:1.0.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("com.google.zxing:core:3.5.3")
}
