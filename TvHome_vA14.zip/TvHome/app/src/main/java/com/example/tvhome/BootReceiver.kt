package com.example.tvhome

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Nach dem Hochfahren und nach Updates: startet den Wächter-Dienst,
 * der den Launcher nach vorne holt (Fire OS 7 erlaubt das ohne Sonderrecht).
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED -> HomeWatchService.start(context, HomeWatchService.REASON_BOOT)
            Intent.ACTION_MY_PACKAGE_REPLACED -> HomeWatchService.start(context, HomeWatchService.REASON_UPDATE)
        }
    }
}
