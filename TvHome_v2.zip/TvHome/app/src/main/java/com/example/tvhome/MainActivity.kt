@file:OptIn(ExperimentalTvMaterial3Api::class)

package com.example.tvhome

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.ExperimentalTvMaterial3Api
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Surface
import androidx.tv.material3.Text
import androidx.tv.material3.darkColorScheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.Locale

data class AppEntry(
    val label: String,
    val packageName: String,
    val icon: ImageBitmap,
    val accent: Color,
)

private const val TILES_PER_ROW = 6

class MainActivity : ComponentActivity() {

    // Wird bei jedem Zurückkehren erhöht, damit neu installierte Apps erscheinen
    private var refresh by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val apps by produceState(emptyList<AppEntry>(), refresh) {
                value = withContext(Dispatchers.IO) { loadApps() }
            }
            val needsAutostart = remember(refresh) { !Settings.canDrawOverlays(this@MainActivity) }
            // Als Home-Bildschirm soll "Zurück" nichts tun
            BackHandler { }
            MaterialTheme(colorScheme = darkColorScheme()) {
                HomeScreen(
                    apps = apps,
                    needsAutostart = needsAutostart,
                    onLaunch = ::launch,
                    onAutostart = ::openAutostartSettings,
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refresh++
    }

    private fun loadApps(): List<AppEntry> {
        val pm = packageManager
        val leanback = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val normal = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return (pm.queryIntentActivities(leanback, 0) + pm.queryIntentActivities(normal, 0))
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .map {
                val bmp = it.loadIcon(pm).toBitmap(192, 192)
                AppEntry(
                    label = it.loadLabel(pm).toString(),
                    packageName = it.activityInfo.packageName,
                    icon = bmp.asImageBitmap(),
                    accent = accentOf(bmp),
                )
            }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
    }

    private fun launch(app: AppEntry) {
        val pm = packageManager
        val intent = pm.getLeanbackLaunchIntentForPackage(app.packageName)
            ?: pm.getLaunchIntentForPackage(app.packageName)
            ?: return
        runCatching { startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    private fun openAutostartSettings() {
        val pkg = Uri.parse("package:$packageName")
        runCatching {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg))
        }.onFailure {
            runCatching { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg)) }
        }
    }
}

/** Durchschnittsfarbe des Icons – färbt Kachel und Hintergrund passend ein. */
private fun accentOf(bmp: Bitmap): Color {
    val small = Bitmap.createScaledBitmap(bmp, 8, 8, true)
    var r = 0L
    var g = 0L
    var b = 0L
    var n = 0
    for (y in 0 until 8) {
        for (x in 0 until 8) {
            val p = small.getPixel(x, y)
            if (android.graphics.Color.alpha(p) > 128) {
                r += android.graphics.Color.red(p)
                g += android.graphics.Color.green(p)
                b += android.graphics.Color.blue(p)
                n++
            }
        }
    }
    if (n == 0) return Color(0xFF3A3A4A)
    return Color(red = (r / n).toInt(), green = (g / n).toInt(), blue = (b / n).toInt())
}

@Composable
private fun rememberNow(): State<LocalDateTime> =
    produceState(LocalDateTime.now()) {
        while (true) {
            value = LocalDateTime.now()
            delay(15_000)
        }
    }

@Composable
fun HomeScreen(
    apps: List<AppEntry>,
    needsAutostart: Boolean,
    onLaunch: (AppEntry) -> Unit,
    onAutostart: () -> Unit,
) {
    var focusedApp by remember { mutableStateOf<AppEntry?>(null) }
    val firstTile = remember { FocusRequester() }
    val now by rememberNow()
    val rows = remember(apps) { apps.chunked(TILES_PER_ROW) }

    // Hintergrund nimmt sanft die Farbe der markierten App an
    val base = focusedApp?.accent ?: Color(0xFF2A2A3A)
    val tint by animateColorAsState(
        targetValue = lerp(base, Color.Black, 0.55f),
        animationSpec = tween(600),
        label = "tint",
    )

    // Beim Start sofort den ersten Eintrag fokussieren
    LaunchedEffect(apps) {
        if (apps.isNotEmpty()) {
            delay(150)
            runCatching { firstTile.requestFocus() }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(tint, Color(0xFF0B0B10))))
    ) {
        Column(Modifier.fillMaxSize()) {
            // Kopfzeile: Begrüßung links, Uhr rechts
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 40.dp, end = 40.dp, top = 24.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = greetingFor(now.hour),
                    color = Color.White,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.SemiBold,
                )
                Spacer(Modifier.weight(1f))
                Clock(now)
            }

            if (needsAutostart) {
                Surface(
                    onClick = onAutostart,
                    modifier = Modifier.padding(start = 40.dp, bottom = 4.dp),
                    shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(12.dp)),
                    scale = ClickableSurfaceDefaults.scale(focusedScale = 1.05f),
                    colors = ClickableSurfaceDefaults.colors(
                        containerColor = Color(0x26FFFFFF),
                        focusedContainerColor = Color(0x59FFFFFF),
                    ),
                ) {
                    Text(
                        text = "Autostart aktivieren",
                        color = Color.White,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    )
                }
            }

            LazyColumn(
                contentPadding = PaddingValues(horizontal = 32.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                itemsIndexed(rows) { index, rowApps ->
                    val content: @Composable () -> Unit = {
                        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            rowApps.forEachIndexed { col, app ->
                                AppTile(
                                    app = app,
                                    onFocus = { focusedApp = app },
                                    onClick = { onLaunch(app) },
                                    modifier = if (index == 0 && col == 0) {
                                        Modifier.focusRequester(firstTile)
                                    } else {
                                        Modifier
                                    },
                                )
                            }
                        }
                    }
                    if (index == 0) {
                        // Erste Reihe in einem hellen, abgerundeten Panel
                        Box(
                            Modifier
                                .clip(RoundedCornerShape(28.dp))
                                .background(Color(0x26FFFFFF))
                                .padding(16.dp)
                        ) { content() }
                    } else {
                        content()
                    }
                }
            }
        }
    }
}

@Composable
private fun AppTile(
    app: AppEntry,
    onFocus: () -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var focused by remember { mutableStateOf(false) }

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Surface(
            onClick = onClick,
            modifier = modifier
                .size(width = 128.dp, height = 76.dp)
                .onFocusChanged {
                    focused = it.isFocused
                    if (it.isFocused) onFocus()
                },
            shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(16.dp)),
            scale = ClickableSurfaceDefaults.scale(focusedScale = 1.12f),
            colors = ClickableSurfaceDefaults.colors(
                containerColor = Color.Transparent,
                focusedContainerColor = Color.Transparent,
            ),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.linearGradient(
                            listOf(lerp(app.accent, Color.Black, 0.5f), app.accent)
                        )
                    ),
                contentAlignment = Alignment.Center,
            ) {
                Image(
                    bitmap = app.icon,
                    contentDescription = app.label,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(11.dp)),
                )
            }
        }
        // App-Name erscheint nur bei der markierten Kachel, wie bei Apple TV
        Text(
            text = if (focused) app.label else "",
            color = Color.White,
            fontSize = 13.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .padding(top = 10.dp)
                .width(128.dp)
                .height(20.dp),
        )
    }
}

@Composable
private fun Clock(now: LocalDateTime, modifier: Modifier = Modifier) {
    val time = DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT).format(now)
    val date = DateTimeFormatter.ofPattern("EEEE, d. MMMM", Locale.getDefault()).format(now)

    Column(modifier = modifier, horizontalAlignment = Alignment.End) {
        Text(text = time, color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Light)
        Text(text = date, color = Color(0xB3FFFFFF), fontSize = 15.sp)
    }
}

private fun greetingFor(hour: Int): String = when (hour) {
    in 5..10 -> "Guten Morgen"
    in 11..17 -> "Guten Tag"
    in 18..22 -> "Guten Abend"
    else -> "Gute Nacht"
}
