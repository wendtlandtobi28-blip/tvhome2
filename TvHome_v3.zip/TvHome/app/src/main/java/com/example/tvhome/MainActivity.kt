@file:OptIn(ExperimentalTvMaterial3Api::class)

package com.example.tvhome

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.ExperimentalTvMaterial3Api
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Surface
import androidx.tv.material3.Text
import androidx.tv.material3.darkColorScheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.Locale

data class AppEntry(
    val label: String,
    val packageName: String,
    val icon: ImageBitmap,
    val accent: Color,
)

private enum class Screen { HOME, ALL_APPS, WALLPAPERS }

/** Diese Apps stehen ganz vorn, in dieser Reihenfolge. Fehlende werden übersprungen. */
private val PINNED_KEYS = listOf("netflix", "prime video", "joyn", "youtube")

private data class Preset(val key: String, val label: String, val colors: List<Color>?)

/** Eigene Verläufe, bewusst ohne fremde Bilder. */
private val PRESETS = listOf(
    Preset("auto", "Automatisch (Farbe der App)", null),
    Preset("aurora", "Aurora", listOf(Color(0xFF0B3D4F), Color(0xFF2A1B4D), Color(0xFF0B0B10))),
    Preset("dusk", "Dämmerung", listOf(Color(0xFF7A2E3A), Color(0xFF3A1E4F), Color(0xFF0B0B10))),
    Preset("ocean", "Ozean", listOf(Color(0xFF0E4D6B), Color(0xFF0B2A3F), Color(0xFF07131E))),
    Preset("night", "Nacht", listOf(Color(0xFF1B2140), Color(0xFF0B0E1C), Color(0xFF05060C))),
    Preset("forest", "Wald", listOf(Color(0xFF1E4A3A), Color(0xFF0F2A22), Color(0xFF060F0C))),
)

private class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("tvhome", Context.MODE_PRIVATE)

    var wallpaper: String
        get() = sp.getString("wallpaper", "auto") ?: "auto"
        set(value) {
            sp.edit().putString("wallpaper", value).apply()
        }

    var customUrls: List<String>
        get() = (sp.getString("custom_urls", "") ?: "").split("\n").filter { it.isNotBlank() }
        set(value) {
            sp.edit().putString("custom_urls", value.joinToString("\n")).apply()
        }
}

class MainActivity : ComponentActivity() {

    // Wird bei jedem Zurückkehren erhöht, damit neu installierte Apps erscheinen
    private var refresh by mutableIntStateOf(0)
    private lateinit var prefs: Prefs

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        setContent {
            val apps by produceState(emptyList<AppEntry>(), refresh) {
                value = withContext(Dispatchers.IO) { loadApps() }
            }
            MaterialTheme(colorScheme = darkColorScheme()) {
                LauncherRoot(apps = apps, prefs = prefs, onLaunch = ::launch)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refresh++
    }

    private fun loadApps(): List<AppEntry> {
        val pm = packageManager
        val leanback = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val normal = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return (pm.queryIntentActivities(leanback, 0) + pm.queryIntentActivities(normal, 0))
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .map {
                val bmp = it.loadIcon(pm).toBitmap(192, 192)
                AppEntry(
                    label = it.loadLabel(pm).toString(),
                    packageName = it.activityInfo.packageName,
                    icon = bmp.asImageBitmap(),
                    accent = accentOf(bmp),
                )
            }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
    }

    private fun launch(app: AppEntry) {
        val pm = packageManager
        val intent = pm.getLeanbackLaunchIntentForPackage(app.packageName)
            ?: pm.getLaunchIntentForPackage(app.packageName)
            ?: return
        runCatching { startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }
}

/** Durchschnittsfarbe des Icons, damit Hintergrund und Kacheln passend eingefärbt werden. */
private fun accentOf(bmp: Bitmap): Color {
    val small = Bitmap.createScaledBitmap(bmp, 8, 8, true)
    var r = 0L
    var g = 0L
    var b = 0L
    var n = 0
    for (y in 0 until 8) {
        for (x in 0 until 8) {
            val p = small.getPixel(x, y)
            if (android.graphics.Color.alpha(p) > 128) {
                r += android.graphics.Color.red(p)
                g += android.graphics.Color.green(p)
                b += android.graphics.Color.blue(p)
                n++
            }
        }
    }
    if (n == 0) return Color(0xFF3A3A4A)
    return Color(red = (r / n).toInt(), green = (g / n).toInt(), blue = (b / n).toInt())
}

private fun pickPinned(apps: List<AppEntry>): List<AppEntry> {
    val named = apps.map { it to it.label.lowercase(Locale.getDefault()) }
    return PINNED_KEYS.mapNotNull { key ->
        named.firstOrNull { it.second.startsWith(key) }?.first
            ?: named.firstOrNull { it.second.contains(key) }?.first
    }.distinctBy { it.packageName }
}

private fun downloadBitmap(url: String): ImageBitmap? = runCatching {
    val connection = URL(url).openConnection() as HttpURLConnection
    connection.connectTimeout = 10_000
    connection.readTimeout = 20_000
    connection.instanceFollowRedirects = true
    connection.inputStream.use { stream ->
        BitmapFactory.decodeStream(stream, null, BitmapFactory.Options().apply { inSampleSize = 2 })
    }?.asImageBitmap()
}.getOrNull()

@Composable
private fun rememberRemoteImage(url: String?): ImageBitmap? {
    val image by produceState<ImageBitmap?>(initialValue = null, key1 = url) {
        if (url != null) {
            value = withContext(Dispatchers.IO) { downloadBitmap(url) }
        }
    }
    return image
}

@Composable
private fun rememberNow(): State<LocalDateTime> =
    produceState(LocalDateTime.now()) {
        while (true) {
            value = LocalDateTime.now()
            delay(15_000)
        }
    }

@Composable
private fun LauncherRoot(apps: List<AppEntry>, prefs: Prefs, onLaunch: (AppEntry) -> Unit) {
    var screen by remember { mutableStateOf(Screen.HOME) }
    var focusedApp by remember { mutableStateOf<AppEntry?>(null) }
    var wallpaper by remember { mutableStateOf(prefs.wallpaper) }
    var customUrls by remember { mutableStateOf(prefs.customUrls) }

    val pinned = remember(apps) { pickPinned(apps) }
    val others = remember(apps, pinned) {
        apps.filter { app -> pinned.none { it.packageName == app.packageName } }
    }
    val remoteUrl = if (wallpaper.startsWith("url:")) wallpaper.removePrefix("url:") else null
    val remoteImage = rememberRemoteImage(remoteUrl)

    // Zurück-Taste geht eine Ebene zurück. Auf dem Startbildschirm passiert nichts.
    BackHandler {
        screen = when (screen) {
            Screen.WALLPAPERS -> Screen.ALL_APPS
            else -> Screen.HOME
        }
    }

    Box(Modifier.fillMaxSize()) {
        Background(
            key = wallpaper,
            accent = focusedApp?.accent ?: Color(0xFF2A2A3A),
            image = remoteImage,
        )
        when (screen) {
            Screen.HOME -> HomeScreen(
                pinned = pinned,
                focusedApp = focusedApp,
                onFocusApp = { focusedApp = it },
                onLaunch = onLaunch,
                onAllApps = { screen = Screen.ALL_APPS },
            )
            Screen.ALL_APPS -> AllAppsScreen(
                apps = others,
                onLaunch = onLaunch,
                onHome = { screen = Screen.HOME },
                onWallpapers = { screen = Screen.WALLPAPERS },
            )
            Screen.WALLPAPERS -> WallpaperScreen(
                current = wallpaper,
                customUrls = customUrls,
                onSelect = { key ->
                    wallpaper = key
                    prefs.wallpaper = key
                },
                onAddUrl = { url ->
                    if (url !in customUrls) {
                        customUrls = customUrls + url
                        prefs.customUrls = customUrls
                    }
                    wallpaper = "url:$url"
                    prefs.wallpaper = wallpaper
                },
                onRemoveUrl = { url ->
                    customUrls = customUrls - url
                    prefs.customUrls = customUrls
                    if (wallpaper == "url:$url") {
                        wallpaper = "auto"
                        prefs.wallpaper = "auto"
                    }
                },
                onBack = { screen = Screen.ALL_APPS },
            )
        }
    }
}

@Composable
private fun Background(key: String, accent: Color, image: ImageBitmap?) {
    val tint by animateColorAsState(
        targetValue = lerp(accent, Color.Black, 0.55f),
        animationSpec = tween(700),
        label = "tint",
    )

    if (key.startsWith("url:") && image != null) {
        Image(
            bitmap = image,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
        )
        Box(Modifier.fillMaxSize().background(Color(0x66000000)))
        return
    }

    val preset = PRESETS.firstOrNull { it.key == key }?.colors
    if (preset != null) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(preset))) {
            Glow(preset.first())
        }
    } else {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(tint, Color(0xFF0B0B10))))) {
            Glow(tint)
        }
    }
}

@Composable
private fun Glow(color: Color) {
    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    listOf(color.copy(alpha = 0.45f), Color.Transparent),
                    radius = 1300f,
                )
            )
    )
}

@Composable
private fun HomeScreen(
    pinned: List<AppEntry>,
    focusedApp: AppEntry?,
    onFocusApp: (AppEntry) -> Unit,
    onLaunch: (AppEntry) -> Unit,
    onAllApps: () -> Unit,
) {
    val now by rememberNow()
    val firstFocus = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        delay(150)
        runCatching { firstFocus.requestFocus() }
    }

    Box(Modifier.fillMaxSize().padding(horizontal = 40.dp, vertical = 28.dp)) {
        // Glasleiste oben links
        Row(
            modifier = Modifier
                .align(Alignment.TopStart)
                .clip(RoundedCornerShape(36.dp))
                .background(Brush.verticalGradient(listOf(Color(0x40FFFFFF), Color(0x1AFFFFFF))))
                .border(1.dp, Color(0x40FFFFFF), RoundedCornerShape(36.dp))
                .padding(horizontal = 18.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            pinned.forEachIndexed { index, app ->
                AppTile(
                    app = app,
                    large = false,
                    onFocus = { onFocusApp(app) },
                    onClick = { onLaunch(app) },
                    focusRequester = if (index == 0) firstFocus else null,
                )
            }
            AllAppsTile(
                onClick = onAllApps,
                focusRequester = if (pinned.isEmpty()) firstFocus else null,
            )
        }

        Clock(now = now, modifier = Modifier.align(Alignment.TopEnd))

        Text(
            text = focusedApp?.label.orEmpty(),
            color = Color.White,
            fontSize = 30.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 8.dp, bottom = 8.dp),
        )
    }
}

@Composable
private fun AllAppsScreen(
    apps: List<AppEntry>,
    onLaunch: (AppEntry) -> Unit,
    onHome: () -> Unit,
    onWallpapers: () -> Unit,
) {
    val firstFocus = remember { FocusRequester() }
    LaunchedEffect(apps.size) {
        delay(150)
        runCatching { firstFocus.requestFocus() }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 48.dp, vertical = 36.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "Alle Apps",
                color = Color.White,
                fontSize = 30.sp,
                fontWeight = FontWeight.SemiBold,
            )
            Spacer(Modifier.weight(1f))
            ChipButton(text = "Hintergrund", onClick = onWallpapers)
            Spacer(Modifier.width(12.dp))
            ChipButton(text = "Start", onClick = onHome)
        }
        Spacer(Modifier.height(28.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(5),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            itemsIndexed(apps) { index, app ->
                AppTile(
                    app = app,
                    large = true,
                    onFocus = {},
                    onClick = { onLaunch(app) },
                    focusRequester = if (index == 0) firstFocus else null,
                )
            }
        }
    }
}

@Composable
private fun WallpaperScreen(
    current: String,
    customUrls: List<String>,
    onSelect: (String) -> Unit,
    onAddUrl: (String) -> Unit,
    onRemoveUrl: (String) -> Unit,
    onBack: () -> Unit,
) {
    val firstFocus = remember { FocusRequester() }
    var input by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        delay(150)
        runCatching { firstFocus.requestFocus() }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 48.dp, vertical = 36.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "Hintergrund",
                color = Color.White,
                fontSize = 30.sp,
                fontWeight = FontWeight.SemiBold,
            )
            Spacer(Modifier.weight(1f))
            ChipButton(
                text = "Zurück",
                onClick = onBack,
                modifier = Modifier.focusRequester(firstFocus),
            )
        }

        Text(text = "Vorgaben", color = Color(0xB3FFFFFF), fontSize = 16.sp)
        PRESETS.forEach { preset ->
            val mark = if (current == preset.key) "✓  " else ""
            ChipButton(text = mark + preset.label, onClick = { onSelect(preset.key) })
        }

        Spacer(Modifier.height(12.dp))
        Text(text = "Eigene Bilder (Internet-Adresse)", color = Color(0xB3FFFFFF), fontSize = 16.sp)
        customUrls.forEach { url ->
            val mark = if (current == "url:$url") "✓  " else ""
            Row(verticalAlignment = Alignment.CenterVertically) {
                ChipButton(
                    text = mark + url.take(70),
                    onClick = { onSelect("url:$url") },
                    modifier = Modifier.weight(1f),
                )
                Spacer(Modifier.width(12.dp))
                ChipButton(text = "Entfernen", onClick = { onRemoveUrl(url) })
            }
        }

        BasicTextField(
            value = input,
            onValueChange = {
                input = it
                error = null
            },
            singleLine = true,
            textStyle = TextStyle(color = Color.White, fontSize = 18.sp),
            cursorBrush = SolidColor(Color.White),
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0x26FFFFFF))
                .padding(horizontal = 18.dp, vertical = 14.dp),
            decorationBox = { innerTextField ->
                Box {
                    if (input.isEmpty()) {
                        Text(
                            text = "Adresse eingeben, z. B. https://…",
                            color = Color(0x80FFFFFF),
                            fontSize = 18.sp,
                        )
                    }
                    innerTextField()
                }
            },
        )

        ChipButton(
            text = "Bild hinzufügen",
            onClick = {
                val url = input.trim()
                if (url.startsWith("https://") || url.startsWith("http://")) {
                    onAddUrl(url)
                    input = ""
                } else {
                    error = "Die Adresse muss mit https:// beginnen."
                }
            },
        )
        error?.let { Text(text = it, color = Color(0xFFFF8A80), fontSize = 15.sp) }
        Text(
            text = "Bilder werden aus dem Internet geladen. Nutze nur Bilder, die du verwenden darfst.",
            color = Color(0x80FFFFFF),
            fontSize = 14.sp,
        )
    }
}

@Composable
private fun ChipButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Surface(
        onClick = onClick,
        modifier = modifier,
        shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(14.dp)),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1.04f),
        colors = ClickableSurfaceDefaults.colors(
            containerColor = Color(0x26FFFFFF),
            contentColor = Color.White,
            focusedContainerColor = Color(0xE6FFFFFF),
            focusedContentColor = Color.Black,
        ),
    ) {
        Text(
            text = text,
            fontSize = 18.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
        )
    }
}

@Composable
private fun AllAppsTile(onClick: () -> Unit, focusRequester: FocusRequester?) {
    var mod = Modifier.size(width = 112.dp, height = 68.dp)
    if (focusRequester != null) mod = mod.focusRequester(focusRequester)

    Surface(
        onClick = onClick,
        modifier = mod,
        shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(16.dp)),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1.12f),
        colors = ClickableSurfaceDefaults.colors(
            containerColor = Color(0x26FFFFFF),
            focusedContainerColor = Color(0x66FFFFFF),
        ),
    ) {
        // Vier kleine Vierecke als Symbol für "alle Apps"
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                listOf(
                    listOf(Color(0xFFFF5A5F), Color(0xFF5AC8FA)),
                    listOf(Color(0xFF34C759), Color(0xFFFFCC00)),
                ).forEach { rowColors ->
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        rowColors.forEach { c ->
                            Box(
                                Modifier
                                    .size(16.dp)
                                    .clip(RoundedCornerShape(5.dp))
                                    .background(c)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AppTile(
    app: AppEntry,
    large: Boolean,
    onFocus: () -> Unit,
    onClick: () -> Unit,
    focusRequester: FocusRequester? = null,
) {
    val tileWidth = if (large) 140.dp else 112.dp
    val tileHeight = if (large) 96.dp else 68.dp
    val iconSize = if (large) 56.dp else 44.dp

    var mod = Modifier
        .size(width = tileWidth, height = tileHeight)
        .onFocusChanged { if (it.isFocused) onFocus() }
    if (focusRequester != null) mod = mod.focusRequester(focusRequester)

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Surface(
            onClick = onClick,
            modifier = mod,
            shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(18.dp)),
            scale = ClickableSurfaceDefaults.scale(focusedScale = 1.12f),
            colors = ClickableSurfaceDefaults.colors(
                containerColor = Color(0x22FFFFFF),
                focusedContainerColor = Color(0x55FFFFFF),
            ),
        ) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Image(
                    bitmap = app.icon,
                    contentDescription = app.label,
                    modifier = Modifier
                        .size(iconSize)
                        .clip(RoundedCornerShape(12.dp)),
                )
            }
        }
        if (large) {
            Spacer(Modifier.height(8.dp))
            Text(
                text = app.label,
                color = Color.White,
                fontSize = 14.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier.width(tileWidth),
            )
        }
    }
}

@Composable
private fun Clock(now: LocalDateTime, modifier: Modifier = Modifier) {
    val time = DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT).format(now)
    val date = DateTimeFormatter.ofPattern("EEEE, d. MMMM", Locale.getDefault()).format(now)

    Column(modifier = modifier, horizontalAlignment = Alignment.End) {
        Text(text = greetingFor(now.hour), color = Color(0xB3FFFFFF), fontSize = 15.sp)
        Text(text = time, color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Light)
        Text(text = date, color = Color(0xB3FFFFFF), fontSize = 15.sp)
    }
}

private fun greetingFor(hour: Int): String = when (hour) {
    in 5..10 -> "Guten Morgen"
    in 11..17 -> "Guten Tag"
    in 18..22 -> "Guten Abend"
    else -> "Gute Nacht"
}
