package com.example.tvhome

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper

/**
 * Läuft im Hintergrund und holt TV Home zurück nach vorne:
 *  - nach dem Hochfahren (mehrmals, falls sich der Amazon-Startbildschirm darüber legt)
 *  - nach einem Update
 *  - kurz nachdem die Home-Taste der Fernbedienung gedrückt wurde
 */
class HomeWatchService : Service() {

    companion object {
        const val REASON_BOOT = "boot"
        const val REASON_UPDATE = "update"
        const val REASON_APP = "app"
        private const val EXTRA_REASON = "reason"
        private const val CHANNEL = "tvhome_watch"

        fun start(context: Context, reason: String = REASON_APP) {
            val i = Intent(context, HomeWatchService::class.java).putExtra(EXTRA_REASON, reason)
            runCatching {
                if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i) else context.startService(i)
            }
        }

        /** Darf der Launcher nach der Home-Taste zurückkommen? (Einstellungen → Bildschirm) */
        fun autoReturnOn(context: Context): Boolean =
            context.getSharedPreferences("tvhome", Context.MODE_PRIVATE).getBoolean("auto_return", true)
    }

    private val handler = Handler(Looper.getMainLooper())

    /** Die Home-Taste schickt dieses Signal an alle Apps ("homekey"). */
    private val homeKeyReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.getStringExtra("reason") != "homekey") return
            if (!autoReturnOn(context)) return
            handler.removeCallbacksAndMessages(null)
            // Kurz warten, bis der Amazon-Startbildschirm offen ist, dann zurückholen
            handler.postDelayed({ bringToFront() }, 1_200)
            handler.postDelayed({ bringToFrontIfNoAppStarted() }, 3_000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        startForeground(1, buildNotification())
        registerReceiver(homeKeyReceiver, IntentFilter(Intent.ACTION_CLOSE_SYSTEM_DIALOGS))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.getStringExtra(EXTRA_REASON)) {
            REASON_BOOT -> {
                // Sofort und danach noch ein paar Mal, weil Amazon seinen Startbildschirm teils später öffnet.
                // Wurde inzwischen eine App gestartet (z. B. Netflix), wird nichts mehr nach vorne geholt.
                bringToFront()
                handler.postDelayed({ bringToFrontIfNoAppStarted() }, 3_000)
                handler.postDelayed({ bringToFrontIfNoAppStarted() }, 7_000)
                handler.postDelayed({ bringToFrontIfNoAppStarted() }, 12_000)
            }
            REASON_UPDATE -> handler.postDelayed({ bringToFront() }, 500)
        }
        return START_STICKY
    }

    /** Nur nachholen, wenn man nicht gerade eine App gestartet oder im Launcher etwas gedrückt hat */
    private fun bringToFrontIfNoAppStarted() {
        val now = System.currentTimeMillis()
        if (now - MainActivity.lastAppLaunch > 15_000 && now - MainActivity.lastInteraction > 4_000) bringToFront()
    }

    private fun bringToFront() {
        runCatching {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                    .putExtra(MainActivity.EXTRA_GO_HOME, true)
            )
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "TV Home im Hintergrund", NotificationManager.IMPORTANCE_MIN)
            )
            Notification.Builder(this, CHANNEL)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        return builder
            .setContentTitle("TV Home von Tobi")
            .setContentText("Hält den Launcher bereit")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(homeKeyReceiver) }
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
