@file:OptIn(ExperimentalTvMaterial3Api::class)

package com.example.tvhome

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.ExperimentalTvMaterial3Api
import androidx.tv.material3.Text
import kotlinx.coroutines.delay
import java.time.LocalDateTime

/** Gemeinsamer Rahmen für alle Einstellungs-Seiten: Titel, Zurück, scrollbarer Inhalt. */
@Composable
private fun SettingsPage(
    title: String,
    onBack: () -> Unit,
    backFocus: FocusRequester? = null,
    content: @Composable () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 56.dp, vertical = 36.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = title, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.weight(1f))
            ChipButton(
                text = "Zurück",
                onClick = onBack,
                modifier = if (backFocus != null) Modifier.focusRequester(backFocus) else Modifier,
            )
        }
        content()
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(text = text, color = Color(0xB3FFFFFF), fontSize = 16.sp, modifier = Modifier.padding(top = 8.dp))
}

@Composable
private fun rememberFirstFocus(): FocusRequester {
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(150)
        runCatching { focus.requestFocus() }
    }
    return focus
}

/** Startseite der Einstellungen-App */
@Composable
fun SettingsScreen(onOpen: (Screen) -> Unit, onBack: () -> Unit) {
    val first = rememberFirstFocus()
    SettingsPage(title = "Einstellungen", onBack = onBack) {
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            NameTile("Uhr", { onOpen(Screen.CLOCK) }, Modifier.weight(1f), focusRequester = first)
            NameTile("Widgets", { onOpen(Screen.WIDGETS) }, Modifier.weight(1f))
            NameTile("Hintergrund", { onOpen(Screen.WALLPAPERS) }, Modifier.weight(1f))
            NameTile("Bildschirm", { onOpen(Screen.DISPLAY) }, Modifier.weight(1f))
            NameTile("Software-Update", { onOpen(Screen.UPDATE) }, Modifier.weight(1f))
        }
    }
}

/** Uhr-Stil wählen, mit Vorschau */
@Composable
fun ClockStyleScreen(
    current: String,
    now: LocalDateTime,
    onSelect: (String) -> Unit,
    clockMove: Boolean,
    onToggleMove: () -> Unit,
    onBack: () -> Unit,
) {
    val first = rememberFirstFocus()
    SettingsPage(title = "Uhr", onBack = onBack) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(220.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0x33000000)),
            contentAlignment = Alignment.Center,
        ) {
            // Vorschau etwas kleiner
            Box(Modifier.padding(8.dp)) {
                ClockPreview(now = now, style = current)
            }
        }
        SectionLabel("Stil")
        CLOCK_STYLES.entries.chunked(3).forEachIndexed { rowIndex, row ->
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                row.forEachIndexed { i, (key, label) ->
                    val mark = if (key == current) "✓  " else ""
                    ChipButton(
                        text = mark + label,
                        onClick = { onSelect(key) },
                        modifier = if (rowIndex == 0 && i == 0) Modifier.focusRequester(first) else Modifier,
                    )
                }
            }
        }
        SectionLabel("Bewegung")
        ChipButton(
            text = "Uhr leicht bewegen: " + if (clockMove) "an" else "aus",
            onClick = onToggleMove,
        )
        Text(
            text = "Für OLED-Fernseher empfohlen: Die Uhr verschiebt sich alle 2 Minuten ein kleines Stück, " +
                "damit sich nichts einbrennt. Bei LCD-Bildschirmen nicht nötig.",
            color = Color(0xB3FFFFFF),
            fontSize = 15.sp,
        )
    }
}

/** Bildschirm-Einstellungen: Ruhemodus verhindern */
@Composable
fun DisplayScreen(keepAwake: Boolean, onToggleKeepAwake: () -> Unit, onBack: () -> Unit) {
    val first = rememberFirstFocus()
    SettingsPage(title = "Bildschirm", onBack = onBack) {
        ChipButton(
            text = "Ruhemodus verhindern: " + if (keepAwake) "an" else "aus",
            onClick = onToggleKeepAwake,
            modifier = Modifier.focusRequester(first),
        )
        Text(
            text = "Solange der Startbildschirm zu sehen ist, gehen Bildschirmschoner und Ruhemodus nicht an. " +
                "In anderen Apps entscheiden diese selbst.",
            color = Color(0xB3FFFFFF),
            fontSize = 15.sp,
        )
    }
}

/** Kleine Vorschau der Uhr für die Einstellungen */
@Composable
private fun ClockPreview(now: LocalDateTime, style: String) {
    Box(Modifier.width(560.dp).height(200.dp), contentAlignment = Alignment.Center) {
        Box(Modifier.scale(if (style == "analog") 0.6f else 0.75f)) {
            Clock(now = now, style = style)
        }
    }
}

/** Widgets ein-/ausschalten und Reihenfolge ändern */
@Composable
fun WidgetScreen(
    order: List<String>,
    enabled: Set<String>,
    onToggle: (String) -> Unit,
    onMove: (String, Int) -> Unit,
    onBack: () -> Unit,
) {
    val first = rememberFirstFocus()
    SettingsPage(title = "Widgets", onBack = onBack) {
        Text(
            text = "Die Widgets stehen rechts auf dem Startbildschirm, von oben nach unten in dieser Reihenfolge.",
            color = Color(0xB3FFFFFF),
            fontSize = 16.sp,
        )
        order.forEachIndexed { index, id ->
            val on = id in enabled
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ChipButton(
                    text = (if (on) "✓  " else "○  ") + (WIDGETS[id] ?: id) + if (on) "  (an)" else "  (aus)",
                    onClick = { onToggle(id) },
                    modifier = Modifier.width(320.dp).then(if (index == 0) Modifier.focusRequester(first) else Modifier),
                )
                ChipButton(text = "▲ nach oben", onClick = { onMove(id, -1) })
                ChipButton(text = "▼ nach unten", onClick = { onMove(id, 1) })
            }
        }
    }
}

@Composable
fun WallpaperScreen(
    current: String,
    customUrls: List<String>,
    onSelect: (String) -> Unit,
    onAddUrl: (String) -> Unit,
    onRemoveUrl: (String) -> Unit,
    onBack: () -> Unit,
) {
    val first = rememberFirstFocus()
    var input by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    SettingsPage(title = "Hintergrund", onBack = onBack) {
        SectionLabel("Vorgaben")
        PRESETS.chunked(5).forEachIndexed { rowIndex, row ->
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                row.forEachIndexed { i, preset ->
                    val mark = if (current == preset.key) "✓  " else ""
                    ChipButton(
                        text = mark + preset.label,
                        onClick = { onSelect(preset.key) },
                        modifier = if (rowIndex == 0 && i == 0) Modifier.focusRequester(first) else Modifier,
                    )
                }
            }
        }

        SectionLabel("Eigene Bilder (Internet-Adresse)")
        customUrls.forEach { url ->
            val mark = if (current == "url:$url") "✓  " else ""
            Row(verticalAlignment = Alignment.CenterVertically) {
                ChipButton(
                    text = mark + url.take(70),
                    onClick = { onSelect("url:$url") },
                    modifier = Modifier.weight(1f),
                )
                Spacer(Modifier.width(12.dp))
                ChipButton(text = "Entfernen", onClick = { onRemoveUrl(url) })
            }
        }

        BasicTextField(
            value = input,
            onValueChange = {
                input = it
                error = null
            },
            singleLine = true,
            textStyle = TextStyle(color = Color.White, fontSize = 18.sp),
            cursorBrush = SolidColor(Color.White),
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0x26FFFFFF))
                .padding(horizontal = 18.dp, vertical = 14.dp),
            decorationBox = { innerTextField ->
                Box {
                    if (input.isEmpty()) {
                        Text(text = "Adresse eingeben, z. B. https://…", color = Color(0x80FFFFFF), fontSize = 18.sp)
                    }
                    innerTextField()
                }
            },
        )

        ChipButton(
            text = "Bild hinzufügen",
            onClick = {
                val url = input.trim()
                if (url.startsWith("https://") || url.startsWith("http://")) {
                    onAddUrl(url)
                    input = ""
                } else {
                    error = "Die Adresse muss mit https:// beginnen."
                }
            },
        )
        error?.let { Text(text = it, color = Color(0xFFFF8A80), fontSize = 15.sp) }
        Text(
            text = "Bilder werden aus dem Internet geladen. Nutze nur Bilder, die du verwenden darfst.",
            color = Color(0x80FFFFFF),
            fontSize = 14.sp,
        )
    }
}
