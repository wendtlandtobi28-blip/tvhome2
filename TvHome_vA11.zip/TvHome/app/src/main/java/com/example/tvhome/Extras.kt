@file:OptIn(ExperimentalTvMaterial3Api::class)
@file:Suppress("DEPRECATION")

package com.example.tvhome

import android.app.PendingIntent
import android.bluetooth.BluetoothA2dp
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothProfile
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.graphics.Bitmap
import android.net.ConnectivityManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.ExperimentalTvMaterial3Api
import androidx.tv.material3.Text
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import kotlinx.coroutines.delay
import org.json.JSONObject
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.URL
import java.net.URLDecoder
import java.time.Instant
import kotlin.concurrent.thread

// ======================= Einstellungen =======================

/** Wetter für Hamburg-Volksdorf */
const val WEATHER_PLACE = "Volksdorf"
const val WEATHER_LAT = 53.65
const val WEATHER_LON = 10.16

/** Hier holt sich der Launcher seine Updates (dein GitHub-Repo) */
const val GITHUB_REPO = "wendtlandtobi28-blip/tvhome2"
const val UPDATE_APK_URL = "https://github.com/$GITHUB_REPO/releases/download/latest/app-debug.apk"

/** Port der kleinen Update-Seite im WLAN (für den QR-Code) */
const val SERVER_PORT = 8765

// ======================= Status (WLAN + Bluetooth) =======================

data class DeviceStatus(
    val wifiName: String = "WLAN",
    val wifiDetail: String = "",
    val btName: String = "Bluetooth",
    val btDetail: String = "",
    /** 0 = kein WLAN, 1..3 = Balken */
    val wifiLevel: Int = 0,
    val btConnected: Boolean = false,
)

class StatusReader(private val context: Context) {
    private var a2dp: BluetoothA2dp? = null

    init {
        runCatching {
            BluetoothAdapter.getDefaultAdapter()?.getProfileProxy(
                context,
                object : BluetoothProfile.ServiceListener {
                    override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
                        a2dp = proxy as BluetoothA2dp
                    }

                    override fun onServiceDisconnected(profile: Int) {
                        a2dp = null
                    }
                },
                BluetoothProfile.A2DP,
            )
        }
    }

    fun read(): DeviceStatus {
        var wifiName = "WLAN"
        var wifiDetail = ""
        var wifiLevel = 0
        runCatching {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val ni = cm.activeNetworkInfo
            if (ni == null || !ni.isConnected) {
                wifiName = "Nicht verbunden"
                wifiDetail = "WLAN"
            } else if (ni.type == ConnectivityManager.TYPE_ETHERNET) {
                wifiName = "LAN-Kabel"
                wifiDetail = "verbunden"
                wifiLevel = 3
            } else {
                val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                val info = wm.connectionInfo
                var ssid = info.ssid ?: ""
                if (ssid.isBlank() || ssid.contains("unknown ssid")) ssid = "WLAN verbunden"
                wifiName = ssid.replace("\"", "")
                val pct = WifiManager.calculateSignalLevel(info.rssi, 101).coerceIn(0, 100)
                wifiDetail = "Signal $pct %"
                wifiLevel = when {
                    pct >= 67 -> 3
                    pct >= 34 -> 2
                    else -> 1
                }
            }
        }

        var btName = "Bluetooth"
        var btDetail = ""
        var btConnected = false
        runCatching {
            val adapter = BluetoothAdapter.getDefaultAdapter()
            if (adapter == null || !adapter.isEnabled) {
                btName = "Bluetooth aus"
            } else {
                val device = a2dp?.connectedDevices?.firstOrNull()
                if (device == null) {
                    btName = "Kein Gerät"
                    btDetail = "Bluetooth"
                } else {
                    btName = device.name ?: "Gerät"
                    btDetail = "verbunden"
                    btConnected = true
                }
            }
        }
        return DeviceStatus(wifiName, wifiDetail, btName, btDetail, wifiLevel, btConnected)
    }

    fun close() {
        runCatching { a2dp?.let { BluetoothAdapter.getDefaultAdapter()?.closeProfileProxy(BluetoothProfile.A2DP, it) } }
    }
}

// ======================= Wetter (Open-Meteo, ohne Anmeldung) =======================

data class Weather(val text: String, val code: Int)

fun loadWeather(): Weather? = runCatching {
    val url = URL(
        "https://api.open-meteo.com/v1/forecast?latitude=$WEATHER_LAT&longitude=$WEATHER_LON" +
            "&current=temperature_2m,weather_code&timezone=Europe%2FBerlin"
    )
    val con = url.openConnection() as HttpURLConnection
    con.connectTimeout = 10_000
    con.readTimeout = 10_000
    val body = con.inputStream.bufferedReader().use { it.readText() }
    val cur = JSONObject(body).getJSONObject("current")
    val temp = Math.round(cur.getDouble("temperature_2m"))
    val code = cur.getInt("weather_code")
    Weather("$temp °C · ${weatherText(code)}", code)
}.getOrNull()

private fun weatherText(c: Int) = when (c) {
    0 -> "klar"
    1 -> "heiter"
    2 -> "leicht bewölkt"
    3 -> "bewölkt"
    45, 48 -> "Nebel"
    in 51..57 -> "Niesel"
    in 61..67 -> "Regen"
    in 71..77 -> "Schnee"
    in 80..82 -> "Schauer"
    85, 86 -> "Schneeschauer"
    in 95..99 -> "Gewitter"
    else -> ""
}

// ======================= Infos rechts =======================

/** Schriftfarbe auf dem Startbildschirm (dunkel bei hellen Hintergründen) */
val LocalFg = compositionLocalOf { Color.White }

/** Alle Widgets, die es gibt: Kennung -> Name in den Einstellungen */
val WIDGETS = linkedMapOf(
    "weather" to "Wetter",
    "wifi" to "WLAN",
    "bt" to "Bluetooth",
    "date" to "Datum",
)

private val GERMAN = java.util.Locale.GERMANY

@Composable
fun InfoPanel(
    widgets: List<String>,
    status: DeviceStatus,
    weather: Weather?,
    now: java.time.LocalDateTime,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.End,
    ) {
        widgets.forEach { id ->
            when (id) {
                "weather" -> InfoRow(weather?.text ?: "Wetter lädt …", WEATHER_PLACE) { WeatherIcon(weather?.code ?: 3) }
                "wifi" -> InfoRow(status.wifiName, status.wifiDetail) { WifiIcon(status.wifiLevel) }
                "bt" -> InfoRow(status.btName, status.btDetail) { SoundIcon(status.btConnected) }
                "date" -> InfoRow(
                    now.format(java.time.format.DateTimeFormatter.ofPattern("EEEE", GERMAN)),
                    now.format(java.time.format.DateTimeFormatter.ofPattern("d. MMMM yyyy", GERMAN)),
                ) { CalendarIcon(now.dayOfMonth) }
            }
        }
    }
}

private val infoShadow = Shadow(color = Color(0x66000000), blurRadius = 12f)

@Composable
private fun InfoRow(top: String, sub: String, icon: @Composable () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        val fg = LocalFg.current
        Column(horizontalAlignment = Alignment.End, modifier = Modifier.width(210.dp)) {
            Text(
                text = top,
                color = fg,
                fontSize = 20.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.End,
                style = TextStyle(shadow = infoShadow),
            )
            if (sub.isNotEmpty()) {
                Text(
                    text = sub,
                    color = fg.copy(alpha = 0.85f),
                    fontSize = 15.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.End,
                    style = TextStyle(shadow = infoShadow),
                )
            }
        }
        Spacer(Modifier.width(14.dp))
        // Symbol in einem runden Glas-Kreis, damit es auf jedem Hintergrund gut lesbar ist
        Box(
            modifier = Modifier.size(48.dp).clip(CircleShape).background(Color(0x47000000)),
            contentAlignment = Alignment.Center,
        ) { icon() }
    }
}

// ======================= Update =======================

/** Gemeinsamer Zustand für Update-Anzeige */
object UpdateState {
    var status by mutableStateOf("Noch nicht gesucht")
    var available by mutableStateOf(false)
    var busy by mutableStateOf(false)
}

private val mainHandler = Handler(Looper.getMainLooper())
private fun onMain(block: () -> Unit) { mainHandler.post { block() } }

/** Prüft auf GitHub, ob eine neuere APK als die installierte da ist. */
fun checkForUpdate(context: Context) {
    if (UpdateState.busy) return
    onMain { UpdateState.status = "Suche nach Update …" }
    thread {
        runCatching {
            val con = URL("https://api.github.com/repos/$GITHUB_REPO/releases/tags/latest")
                .openConnection() as HttpURLConnection
            con.setRequestProperty("User-Agent", "TvHome-Launcher")
            con.setRequestProperty("Accept", "application/vnd.github+json")
            con.connectTimeout = 10_000
            con.readTimeout = 10_000
            val json = JSONObject(con.inputStream.bufferedReader().use { it.readText() })
            val assets = json.getJSONArray("assets")
            var newest = 0L
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.getString("name").endsWith(".apk")) {
                    newest = maxOf(newest, Instant.parse(a.getString("updated_at")).toEpochMilli())
                }
            }
            val installed = context.packageManager.getPackageInfo(context.packageName, 0).lastUpdateTime
            // Neue APK, wenn sie nach der Installation dieser Version gebaut wurde
            val hasNew = newest > installed + 60_000
            onMain {
                UpdateState.available = hasNew
                UpdateState.status = if (hasNew) "Neues Update verfügbar" else "Du hast die neueste Version"
            }
        }.onFailure {
            onMain { UpdateState.status = "Update-Suche fehlgeschlagen (Internet?)" }
        }
    }
}

/** Lädt eine APK herunter und startet die Installation (Bestätigen am Fernseher). */
fun installFromUrl(context: Context, url: String) {
    if (UpdateState.busy) return
    val app = context.applicationContext
    onMain {
        UpdateState.busy = true
        UpdateState.status = "Update wird geladen …"
    }
    thread {
        runCatching {
            if (Build.VERSION.SDK_INT >= 26 && !app.packageManager.canRequestPackageInstalls()) {
                onMain {
                    Toast.makeText(app, "Bitte TvHome erlauben, Apps zu installieren", Toast.LENGTH_LONG).show()
                    runCatching {
                        app.startActivity(
                            Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${app.packageName}"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                }
            }
            val installer = app.packageManager.packageInstaller
            val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
            val sessionId = installer.createSession(params)
            installer.openSession(sessionId).use { session ->
                val con = URL(url).openConnection() as HttpURLConnection
                con.instanceFollowRedirects = true
                con.connectTimeout = 15_000
                con.readTimeout = 60_000
                con.inputStream.use { input ->
                    session.openWrite("update.apk", 0, -1).use { out ->
                        input.copyTo(out)
                        session.fsync(out)
                    }
                }
                val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                    (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
                val pending = PendingIntent.getBroadcast(
                    app, 0, Intent(app, InstallReceiver::class.java), flags
                )
                session.commit(pending.intentSender)
            }
            onMain { UpdateState.status = "Bitte am Fernseher bestätigen" }
        }.onFailure {
            onMain {
                UpdateState.busy = false
                UpdateState.status = "Update fehlgeschlagen: ${it.message ?: "Fehler"}"
            }
        }
    }
}

/** Bekommt die Antwort vom System-Installer. */
class InstallReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.getIntExtra(PackageInstaller.EXTRA_STATUS, -999)) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                @Suppress("DEPRECATION")
                val confirm = intent.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                confirm?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                runCatching { context.startActivity(confirm) }
            }
            PackageInstaller.STATUS_SUCCESS -> {
                UpdateState.busy = false
                UpdateState.status = "Update installiert"
            }
            else -> {
                UpdateState.busy = false
                val msg = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: "abgebrochen"
                UpdateState.status = "Update nicht installiert: $msg"
                Toast.makeText(context, "Update nicht installiert", Toast.LENGTH_LONG).show()
            }
        }
    }
}

// ======================= Kleine Update-Seite im WLAN (für QR-Code) =======================

fun localIp(): String? = runCatching {
    NetworkInterface.getNetworkInterfaces().toList()
        .filter { it.isUp && !it.isLoopback }
        .flatMap { it.inetAddresses.toList() }
        .firstOrNull { it is Inet4Address && !it.isLoopbackAddress }
        ?.hostAddress
}.getOrNull()

class UpdateServer(private val context: Context) {
    private var socket: ServerSocket? = null

    fun start() {
        if (socket != null) return
        thread(isDaemon = true) {
            runCatching {
                val s = ServerSocket(SERVER_PORT)
                socket = s
                while (!s.isClosed) {
                    val client = s.accept()
                    thread(isDaemon = true) {
                        runCatching {
                            client.use { c ->
                                c.soTimeout = 10_000
                                val line = c.getInputStream().bufferedReader().readLine() ?: ""
                                val path = line.split(" ").getOrNull(1) ?: "/"
                                val html = handle(path)
                                respond(c.getOutputStream(), html)
                            }
                        }
                    }
                }
            }
        }
    }

    fun stop() {
        runCatching { socket?.close() }
        socket = null
    }

    private fun handle(path: String): String {
        if (path.startsWith("/install")) {
            val raw = path.substringAfter("url=", "").substringBefore("&")
            val url = URLDecoder.decode(raw, "UTF-8").trim().ifEmpty { UPDATE_APK_URL }
            return if (url.startsWith("https://") || url.startsWith("http://")) {
                installFromUrl(context, url)
                page("Update läuft", "<p>Die App lädt das Update. Bitte gleich am Fernseher mit OK bestätigen.</p><p><a href=\"/\">Zurück</a></p>")
            } else {
                page("Ungültiger Link", "<p>Der Link muss mit https:// beginnen.</p><p><a href=\"/\">Zurück</a></p>")
            }
        }
        return page(
            "TV Home Update",
            """
            <p>Status am Fernseher: ${escape(UpdateState.status)}</p>
            <p><a class="btn" href="/install?url=${java.net.URLEncoder.encode(UPDATE_APK_URL, "UTF-8")}">Neueste Version von GitHub installieren</a></p>
            <form action="/install" method="get">
              <p>Oder eigenen Link zur APK einfügen:</p>
              <input name="url" placeholder="https://…/app.apk">
              <button type="submit">Update starten</button>
            </form>
            """.trimIndent()
        )
    }

    private fun escape(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    private fun page(title: String, body: String) = """
        <!DOCTYPE html><html lang="de"><head><meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <title>$title</title>
        <style>
          body{font-family:sans-serif;background:#1b1410;color:#fff;padding:24px;max-width:640px;margin:auto}
          a{color:#f6c58f} .btn,button{display:inline-block;background:#f6c58f;color:#2a1a10;padding:14px 20px;
          border-radius:12px;text-decoration:none;font-size:18px;border:0;margin-top:8px}
          input{width:100%;box-sizing:border-box;padding:14px;font-size:17px;border-radius:12px;border:0;margin-top:6px}
        </style></head><body><h1>$title</h1>$body</body></html>
    """.trimIndent()

    private fun respond(out: OutputStream, html: String) {
        val bytes = html.toByteArray(Charsets.UTF_8)
        val head = "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n" +
            "Content-Length: ${bytes.size}\r\nConnection: close\r\n\r\n"
        out.write(head.toByteArray(Charsets.UTF_8))
        out.write(bytes)
        out.flush()
    }
}

fun qrBitmap(text: String, size: Int = 360): Bitmap {
    val matrix = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size)
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.RGB_565)
    for (x in 0 until size) for (y in 0 until size) {
        bmp.setPixel(x, y, if (matrix[x, y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
    }
    return bmp
}

// ======================= Update-Bildschirm =======================

@Composable
fun UpdateScreen(versionName: String, onBack: () -> Unit, onCheck: () -> Unit, onInstall: () -> Unit) {
    val firstFocus = remember { FocusRequester() }
    val ip = remember { localIp() }
    val pageUrl = if (ip != null) "http://$ip:$SERVER_PORT" else null
    val qr = remember(pageUrl) { pageUrl?.let { qrBitmap(it).asImageBitmap() } }

    LaunchedEffect(Unit) {
        delay(150)
        runCatching { firstFocus.requestFocus() }
    }

    Row(
        modifier = Modifier.fillMaxSize().padding(horizontal = 56.dp, vertical = 40.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Software-Update", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.SemiBold)
            Text("Installiert: Version $versionName", color = Color(0xB3FFFFFF), fontSize = 18.sp)
            Text(UpdateState.status, color = Color.White, fontSize = 20.sp)
            Spacer(Modifier.height(8.dp))
            if (UpdateState.available) {
                ChipButton("Update jetzt installieren", onInstall, Modifier.focusRequester(firstFocus))
                ChipButton("Erneut suchen", onCheck)
            } else {
                ChipButton("Nach Update suchen", onCheck, Modifier.focusRequester(firstFocus))
                ChipButton("Trotzdem neu installieren", onInstall)
            }
            ChipButton("Zurück", onBack)
        }
        Spacer(Modifier.width(40.dp))
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            if (qr != null) {
                Box(
                    Modifier.clip(RoundedCornerShape(18.dp)).background(Color.White).padding(14.dp)
                ) {
                    Image(bitmap = qr, contentDescription = "QR-Code", modifier = Modifier.size(230.dp))
                }
                Spacer(Modifier.height(12.dp))
                Text("Mit dem Tablet scannen", color = Color.White, fontSize = 18.sp)
                Text(pageUrl ?: "", color = Color(0xB3FFFFFF), fontSize = 15.sp)
            } else {
                Text("Kein WLAN – QR-Code nicht verfügbar", color = Color.White, fontSize = 18.sp)
            }
        }
    }
}

