@file:OptIn(ExperimentalTvMaterial3Api::class)

package com.example.tvhome

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.ExperimentalTvMaterial3Api
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Surface
import androidx.tv.material3.Text
import androidx.tv.material3.darkColorScheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.PI
import kotlin.math.sin

data class AppEntry(val label: String, val packageName: String)

enum class Screen { HOME, ALL_APPS, SETTINGS, CLOCK, WIDGETS, WALLPAPERS, DISPLAY, FIRETV, UPDATE }

/** Diese Apps stehen ganz vorn, in dieser Reihenfolge. Fehlende werden übersprungen. */
val PINNED_KEYS = listOf("netflix", "prime video", "joyn", "youtube")

/** Hintergrund-Vorgabe. [light] = heller Hintergrund, dann wird die Schrift dunkel. */
data class Preset(val key: String, val label: String, val colors: List<Color>?, val light: Boolean = false)

/** Eigene Hintergründe, bewusst ohne fremde Bilder. */
val PRESETS = listOf(
    Preset("desert", "Wüste", null),
    Preset("black", "Schwarz", listOf(Color(0xFF16161A), Color(0xFF000000))),
    Preset("white", "Weiß", listOf(Color(0xFFFFFFFF), Color(0xFFE4E5EA)), light = true),
    Preset("blue", "Blau", listOf(Color(0xFF2F7BFF), Color(0xFF0D2B6E), Color(0xFF050B1C))),
    Preset("red", "Rot", listOf(Color(0xFFE53935), Color(0xFF6E1010), Color(0xFF1A0404))),
    Preset("orange", "Orange", listOf(Color(0xFFFF8A2A), Color(0xFF8C3A0A), Color(0xFF1C0A03))),
    Preset("pink", "Pink", listOf(Color(0xFFFF5FA8), Color(0xFF7A1E4F), Color(0xFF1A0712))),
    Preset("green", "Grün", listOf(Color(0xFF34B36A), Color(0xFF0E4A2A), Color(0xFF04140B))),
    Preset("violet", "Violett", listOf(Color(0xFF9B6BFF), Color(0xFF3A1E7A), Color(0xFF0D0620))),
    Preset("aurora", "Aurora", listOf(Color(0xFF0B3D4F), Color(0xFF2A1B4D), Color(0xFF0B0B10))),
    Preset("dusk", "Dämmerung", listOf(Color(0xFF7A2E3A), Color(0xFF3A1E4F), Color(0xFF0B0B10))),
    Preset("ocean", "Ozean", listOf(Color(0xFF0E4D6B), Color(0xFF0B2A3F), Color(0xFF07131E))),
    Preset("night", "Nacht", listOf(Color(0xFF1B2140), Color(0xFF0B0E1C), Color(0xFF05060C))),
    Preset("forest", "Wald", listOf(Color(0xFF1E4A3A), Color(0xFF0F2A22), Color(0xFF060F0C))),
)

/** Uhr-Stile: Kennung -> Name */
val CLOCK_STYLES = linkedMapOf(
    "fett" to "Fett (Apple-Stil)",
    "fett_datum" to "Fett mit Datum",
    "mittel" to "Mittel",
    "duenn" to "Dünn",
    "sekunden" to "Mit Sekunden",
    "analog" to "Analog",
)

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("tvhome", Context.MODE_PRIVATE)

    var wallpaper: String
        get() = sp.getString("wallpaper", "desert") ?: "desert"
        set(value) = sp.edit().putString("wallpaper", value).apply()

    var customUrls: List<String>
        get() = (sp.getString("custom_urls", "") ?: "").split("\n").filter { it.isNotBlank() }
        set(value) = sp.edit().putString("custom_urls", value.joinToString("\n")).apply()

    var clockStyle: String
        get() = (sp.getString("clock_style", "fett") ?: "fett").takeIf { it in CLOCK_STYLES } ?: "fett"
        set(value) = sp.edit().putString("clock_style", value).apply()

    /** Reihenfolge aller Widgets (auch ausgeschaltete) */
    var widgetOrder: List<String>
        get() {
            val saved = (sp.getString("widget_order", "") ?: "").split(",").filter { it in WIDGETS }
            return saved + WIDGETS.keys.filter { it !in saved }
        }
        set(value) = sp.edit().putString("widget_order", value.joinToString(",")).apply()

    var askedLocation: Boolean
        get() = sp.getBoolean("asked_location", false)
        set(value) = sp.edit().putBoolean("asked_location", value).apply()

    /** Bildschirm anlassen, solange der Launcher zu sehen ist */
    var keepAwake: Boolean
        get() = sp.getBoolean("keep_awake", true)
        set(value) = sp.edit().putBoolean("keep_awake", value).apply()

    /** Nach der Home-Taste automatisch zurück zu TV Home */
    var autoReturn: Boolean
        get() = sp.getBoolean("auto_return", true)
        set(value) = sp.edit().putBoolean("auto_return", value).apply()

    /** Uhr alle paar Minuten leicht verschieben (gegen Einbrennen bei OLED). Standard: aus */
    var clockMove: Boolean
        get() = sp.getBoolean("clock_move", false)
        set(value) = sp.edit().putBoolean("clock_move", value).apply()

    var widgetsOn: Set<String>
        get() = (sp.getString("widgets_on", "weather,wifi,bt") ?: "").split(",").filter { it in WIDGETS }.toSet()
        set(value) = sp.edit().putString("widgets_on", value.joinToString(",")).apply()
}

class MainActivity : ComponentActivity() {

    // Wird bei jedem Zurückkehren erhöht, damit neu installierte Apps erscheinen
    private var refresh by mutableIntStateOf(0)

    // Wird erhöht, wenn der Launcher von außen zurückgeholt wird -> zurück zum Startbildschirm
    private var goHomeTick by mutableIntStateOf(0)
    private lateinit var prefs: Prefs
    private lateinit var statusReader: StatusReader

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        statusReader = StatusReader(this)
        // Wächter starten: holt den Launcher nach der Home-Taste zurück
        HomeWatchService.start(this)

        // Für den WLAN-Namen braucht Android das Standortrecht
        // Nur einmal fragen, damit beim Hochfahren nicht jedes Mal ein Dialog aufpoppt
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            !prefs.askedLocation
        ) {
            prefs.askedLocation = true
            runCatching { requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1) }
        }
        checkForUpdate(this)

        val versionName = runCatching { packageManager.getPackageInfo(packageName, 0).versionName }
            .getOrNull() ?: "?"

        setContent {
            val apps by produceState<List<AppEntry>?>(null, refresh) {
                value = withContext(Dispatchers.IO) { loadApps() }
            }
            MaterialTheme(colorScheme = darkColorScheme()) {
                LauncherRoot(
                    apps = apps,
                    goHomeTick = goHomeTick,
                    prefs = prefs,
                    onLaunch = ::launch,
                    readStatus = { statusReader.read() },
                    versionName = versionName,
                    onCheckUpdate = { checkForUpdate(this@MainActivity) },
                    onInstallUpdate = { installFromUrl(this@MainActivity, UPDATE_APK_URL) },
                )
            }
        }
    }

    override fun onStart() {
        super.onStart()
        visible = true
    }

    override fun onStop() {
        super.onStop()
        visible = false
        // Verlassen, ohne selbst eine App gestartet zu haben -> sehr wahrscheinlich die Home-Taste
        // (nicht während eines Updates: dann ist der Installations-Dialog von Android vorne)
        if (!isChangingConfigurations && !UpdateState.busy && System.currentTimeMillis() - lastAppLaunch > 3_000) {
            HomeWatchService.onLauncherLeft(this)
        }
    }

    override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean {
        lastInteraction = System.currentTimeMillis()
        return super.dispatchKeyEvent(event)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.getBooleanExtra(EXTRA_GO_HOME, false)) goHomeTick++
    }

    override fun onResume() {
        super.onResume()
        refresh++
    }

    override fun onDestroy() {
        statusReader.close()
        super.onDestroy()
    }

    /** Nur Name und Paket – ohne Symbole, deshalb sehr schnell (auch direkt nach dem Hochfahren). */
    private fun loadApps(): List<AppEntry> {
        val pm = packageManager
        val leanback = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val normal = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return (pm.queryIntentActivities(leanback, 0) + pm.queryIntentActivities(normal, 0))
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { AppEntry(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
    }

    private fun launch(app: AppEntry) {
        val pm = packageManager
        val intent = pm.getLeanbackLaunchIntentForPackage(app.packageName)
            ?: pm.getLaunchIntentForPackage(app.packageName)
            ?: return
        lastAppLaunch = System.currentTimeMillis()
        // Die App im Launcher-Stapel starten: beim Verlassen mit "Zurück" landet man dann wieder hier
        // und nicht auf dem Amazon-Startbildschirm. Klappt das nicht, normal in eigenem Stapel starten.
        val sameTask = Intent(intent).apply { flags = flags and Intent.FLAG_ACTIVITY_NEW_TASK.inv() }
        runCatching { startActivity(sameTask) }
            .onFailure { runCatching { startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
    }

    companion object {
        /** Zeitpunkt, an dem zuletzt eine App aus dem Launcher gestartet wurde */
        @Volatile
        var lastAppLaunch = 0L

        /** Ist der Launcher gerade sichtbar? */
        @Volatile
        var visible = false

        /** Zeitpunkt der letzten Tasten-Eingabe im Launcher */
        @Volatile
        var lastInteraction = 0L

        const val EXTRA_GO_HOME = "go_home"
    }
}

private fun pickPinned(apps: List<AppEntry>): List<AppEntry> {
    val named = apps.map { it to it.label.lowercase(Locale.getDefault()) }
    return PINNED_KEYS.mapNotNull { key ->
        named.firstOrNull { it.second.startsWith(key) }?.first
            ?: named.firstOrNull { it.second.contains(key) }?.first
    }.distinctBy { it.packageName }
}

private fun downloadBitmap(url: String): ImageBitmap? = runCatching {
    val connection = URL(url).openConnection() as HttpURLConnection
    connection.connectTimeout = 10_000
    connection.readTimeout = 20_000
    connection.instanceFollowRedirects = true
    connection.inputStream.use { stream ->
        BitmapFactory.decodeStream(stream, null, BitmapFactory.Options().apply { inSampleSize = 2 })
    }?.asImageBitmap()
}.getOrNull()

@Composable
private fun rememberRemoteImage(url: String?): ImageBitmap? {
    val image by produceState<ImageBitmap?>(initialValue = null, key1 = url) {
        value = if (url != null) withContext(Dispatchers.IO) { downloadBitmap(url) } else null
    }
    return image
}

/** Aktuelle Zeit, genau zum Sekundenwechsel aktualisiert. */
@Composable
private fun rememberNow(): State<LocalDateTime> =
    produceState(LocalDateTime.now()) {
        while (true) {
            value = LocalDateTime.now()
            delay(1_000L - (System.currentTimeMillis() % 1_000L))
        }
    }

@Composable
private fun LauncherRoot(
    apps: List<AppEntry>?,
    goHomeTick: Int,
    prefs: Prefs,
    onLaunch: (AppEntry) -> Unit,
    readStatus: () -> DeviceStatus,
    versionName: String,
    onCheckUpdate: () -> Unit,
    onInstallUpdate: () -> Unit,
) {
    var screen by remember { mutableStateOf(Screen.HOME) }
    var wallpaper by remember { mutableStateOf(prefs.wallpaper) }
    var customUrls by remember { mutableStateOf(prefs.customUrls) }
    var clockStyle by remember { mutableStateOf(prefs.clockStyle) }
    var widgetOrder by remember { mutableStateOf(prefs.widgetOrder) }
    var widgetsOn by remember { mutableStateOf(prefs.widgetsOn) }
    var keepAwake by remember { mutableStateOf(prefs.keepAwake) }
    var clockMove by remember { mutableStateOf(prefs.clockMove) }
    var autoReturn by remember { mutableStateOf(prefs.autoReturn) }

    // Von außen zurückgeholt (Home-Taste, Neustart): immer auf den Startbildschirm
    LaunchedEffect(goHomeTick) {
        if (goHomeTick > 0) screen = Screen.HOME
    }

    // Ruhemodus verhindern: solange der Launcher zu sehen ist, bleibt der Bildschirm an
    val view = LocalView.current
    DisposableEffect(keepAwake) {
        view.keepScreenOn = keepAwake
        onDispose { view.keepScreenOn = false }
    }

    val list = apps ?: emptyList()
    val pinned = remember(list) { pickPinned(list) }
    val others = remember(list, pinned) {
        list.filter { app -> pinned.none { it.packageName == app.packageName } }
    }
    val remoteUrl = if (wallpaper.startsWith("url:")) wallpaper.removePrefix("url:") else null
    val remoteImage = rememberRemoteImage(remoteUrl)
    val light = PRESETS.firstOrNull { it.key == wallpaper }?.light == true

    // Status und Wetter leben hier oben, damit sie beim Wechseln der Ansicht nicht neu geladen werden
    // Als State weitergeben und erst ganz unten lesen: so wird pro Sekunde nur die Uhr neu gezeichnet,
    // nicht der ganze Bildschirm (wichtig für die Leistung auf dem Stick)
    val nowState = rememberNow()
    val statusState = produceState(DeviceStatus()) {
        while (true) {
            value = readStatus()
            delay(5_000)
        }
    }
    val weatherState = produceState<Weather?>(null) {
        while (true) {
            val w = withContext(Dispatchers.IO) { loadWeather() }
            if (w != null) value = w
            delay(if (w != null) 30 * 60_000L else 2 * 60_000L)
        }
    }

    // Alle 6 Stunden im Hintergrund nach Updates schauen
    val context = LocalContext.current
    LaunchedEffect(Unit) {
        while (true) {
            delay(6 * 60 * 60_000L)
            checkForUpdate(context)
        }
    }

    // Zurück-Taste geht eine Ebene zurück. Auf dem Startbildschirm passiert nichts.
    BackHandler {
        screen = when (screen) {
            Screen.CLOCK, Screen.WIDGETS, Screen.WALLPAPERS, Screen.DISPLAY, Screen.FIRETV, Screen.UPDATE -> Screen.SETTINGS
            Screen.SETTINGS -> Screen.ALL_APPS
            else -> Screen.HOME
        }
    }

    Box(Modifier.fillMaxSize()) {
        Background(key = wallpaper, image = remoteImage)
        // Außerhalb des Startbildschirms abdunkeln, damit weiße Schrift auf jedem Hintergrund lesbar ist
        if (screen != Screen.HOME) Box(Modifier.fillMaxSize().background(Color(if (light) 0xA6000000 else 0x80000000)))

        when (screen) {
            Screen.HOME -> CompositionLocalProvider(LocalFg provides if (light) Color(0xFF1C1C1E) else Color.White) {
                HomeScreen(
                    nowState = nowState,
                    clockStyle = clockStyle,
                    clockMove = clockMove,
                    widgets = widgetOrder.filter { it in widgetsOn },
                    statusState = statusState,
                    weatherState = weatherState,
                    pinned = pinned,
                    loaded = apps != null,
                    onLaunch = onLaunch,
                    onAllApps = { screen = Screen.ALL_APPS },
                    onUpdate = { screen = Screen.UPDATE },
                )
            }
            Screen.ALL_APPS -> AllAppsScreen(
                apps = others,
                onLaunch = onLaunch,
                onBack = { screen = Screen.HOME },
                onSettings = { screen = Screen.SETTINGS },
            )
            Screen.SETTINGS -> SettingsScreen(
                onOpen = { screen = it },
                onBack = { screen = Screen.ALL_APPS },
            )
            Screen.CLOCK -> ClockStyleScreen(
                current = clockStyle,
                nowState = nowState,
                onSelect = {
                    clockStyle = it
                    prefs.clockStyle = it
                },
                clockMove = clockMove,
                onToggleMove = {
                    clockMove = !clockMove
                    prefs.clockMove = clockMove
                },
                onBack = { screen = Screen.SETTINGS },
            )
            Screen.DISPLAY -> DisplayScreen(
                keepAwake = keepAwake,
                onToggleKeepAwake = {
                    keepAwake = !keepAwake
                    prefs.keepAwake = keepAwake
                },
                autoReturn = autoReturn,
                onToggleAutoReturn = {
                    autoReturn = !autoReturn
                    prefs.autoReturn = autoReturn
                },
                onBack = { screen = Screen.SETTINGS },
            )
            Screen.WIDGETS -> WidgetScreen(
                order = widgetOrder,
                enabled = widgetsOn,
                onToggle = { id ->
                    widgetsOn = if (id in widgetsOn) widgetsOn - id else widgetsOn + id
                    prefs.widgetsOn = widgetsOn
                },
                onMove = { id, delta ->
                    val i = widgetOrder.indexOf(id)
                    val j = (i + delta).coerceIn(0, widgetOrder.size - 1)
                    if (i >= 0 && i != j) {
                        val m = widgetOrder.toMutableList()
                        m.removeAt(i)
                        m.add(j, id)
                        widgetOrder = m
                        prefs.widgetOrder = m
                    }
                },
                onBack = { screen = Screen.SETTINGS },
            )
            Screen.WALLPAPERS -> WallpaperScreen(
                current = wallpaper,
                customUrls = customUrls,
                onSelect = { key ->
                    wallpaper = key
                    prefs.wallpaper = key
                },
                onAddUrl = { url ->
                    if (url !in customUrls) {
                        customUrls = customUrls + url
                        prefs.customUrls = customUrls
                    }
                    wallpaper = "url:$url"
                    prefs.wallpaper = wallpaper
                },
                onRemoveUrl = { url ->
                    customUrls = customUrls - url
                    prefs.customUrls = customUrls
                    if (wallpaper == "url:$url") {
                        wallpaper = "desert"
                        prefs.wallpaper = "desert"
                    }
                },
                onBack = { screen = Screen.SETTINGS },
            )
            Screen.FIRETV -> FireTvSettingsScreen(onBack = { screen = Screen.SETTINGS })
            Screen.UPDATE -> UpdateScreen(
                versionName = versionName,
                onBack = { screen = Screen.SETTINGS },
                onCheck = onCheckUpdate,
                onInstall = onInstallUpdate,
            )
        }
    }
}

@Composable
private fun Background(key: String, image: ImageBitmap?) {
    if (key.startsWith("url:") && image != null) {
        Image(
            bitmap = image,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
        )
        Box(Modifier.fillMaxSize().background(Color(0x55000000)))
        return
    }
    val preset = PRESETS.firstOrNull { it.key == key }?.colors
    if (preset == null) {
        DesertBackground()
        return
    }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(preset))) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.radialGradient(listOf(preset.first().copy(alpha = 0.45f), Color.Transparent), radius = 1300f))
        )
    }
}

/** Eigene Wüstenszene: heller Himmel, warmer Dunst und mehrere Dünenlagen. */
@Composable
private fun DesertBackground() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFF8DBDEB), Color(0xFFC4DCF0), Color(0xFFF1E4CF)),
                startY = 0f,
                endY = h * 0.6f,
            ),
        )
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color(0x00F1E4CF), Color(0xB3F1E4CF)),
                startY = h * 0.42f,
                endY = h * 0.72f,
            ),
        )
        drawDune(w, h, h * 0.56f, h * 0.025f, 1.3f, 0.4f, Color(0xFFE6D3B3), Color(0xFFD6B48B))
        drawDune(w, h, h * 0.66f, h * 0.04f, 1.8f, 2.1f, Color(0xFFD9BB92), Color(0xFFC39A6C))
        drawDune(w, h, h * 0.79f, h * 0.05f, 1.1f, 4.0f, Color(0xFFC9A074), Color(0xFFAD8052))
        drawDune(w, h, h * 0.93f, h * 0.06f, 0.9f, 5.3f, Color(0xFFB38758), Color(0xFF94663F))
    }
}

private fun DrawScope.drawDune(
    w: Float, h: Float, baseY: Float, amp: Float, freq: Float, phase: Float, top: Color, bottom: Color,
) {
    val path = Path()
    path.moveTo(0f, h)
    val steps = 80
    for (i in 0..steps) {
        val x = w * i / steps
        val t = x / w * 2f * PI.toFloat()
        val y = baseY + amp * (sin(t * freq + phase) * 0.7f + sin(t * freq * 2.3f + phase * 1.7f) * 0.3f)
        path.lineTo(x, y)
    }
    path.lineTo(w, h)
    path.close()
    drawPath(path = path, brush = Brush.verticalGradient(listOf(top, bottom), startY = baseY - amp, endY = h))
}

@Composable
private fun HomeScreen(
    nowState: State<LocalDateTime>,
    clockStyle: String,
    clockMove: Boolean,
    widgets: List<String>,
    statusState: State<DeviceStatus>,
    weatherState: State<Weather?>,
    pinned: List<AppEntry>,
    loaded: Boolean,
    onLaunch: (AppEntry) -> Unit,
    onAllApps: () -> Unit,
    onUpdate: () -> Unit,
) {
    val firstFocus = remember { FocusRequester() }

    // Fokus erst setzen, wenn die Apps geladen sind und die Leiste wirklich da ist
    LaunchedEffect(loaded) {
        if (!loaded) return@LaunchedEffect
        delay(150)
        runCatching { firstFocus.requestFocus() }
    }

    // Nur wenn eingeschaltet: Uhr alle 2 Minuten ein kleines Stück verschieben (gegen Einbrennen)
    val shift by produceState(Pair(0, 0), clockMove) {
        value = Pair(0, 0)
        while (clockMove) {
            delay(120_000)
            value = Pair((-30..30).random(), (-20..20).random())
        }
    }
    val dx by animateDpAsState(shift.first.dp, tween(4_000), label = "dx")
    val dy by animateDpAsState(shift.second.dp, tween(4_000), label = "dy")

    Box(Modifier.fillMaxSize()) {
        LiveClock(nowState = nowState, style = clockStyle, modifier = Modifier.align(Alignment.Center).offset(x = dx, y = (-40).dp + dy))

        // Widgets rechts: von oben bis zur Mitte
        if (widgets.isNotEmpty()) {
            InfoPanel(
                widgets = widgets,
                statusState = statusState,
                weatherState = weatherState,
                nowState = nowState,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 32.dp, end = 44.dp)
                    .fillMaxHeight((0.15f * widgets.size).coerceAtMost(0.5f)),
            )
        }

        // Hinweis oben links, nur wenn wirklich ein Update bereitliegt
        if (UpdateState.available) {
            ChipButton(
                text = "Update verfügbar",
                onClick = onUpdate,
                modifier = Modifier.align(Alignment.TopStart).padding(top = 32.dp, start = 44.dp),
            )
        }

        // Leiste unten. Erst zeigen, wenn die Apps geladen sind (sonst ploppt "Alle Apps" riesig auf).
        if (loaded) Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(horizontal = 32.dp, vertical = 28.dp)
                .clip(RoundedCornerShape(40.dp))
                .background(Brush.verticalGradient(listOf(Color(0x59FFFFFF), Color(0x33FFFFFF))))
                .border(1.dp, Color(0x59FFFFFF), RoundedCornerShape(40.dp))
                // Genug Innenabstand, damit vergrößerte Kacheln nicht am Rand der Leiste anstoßen
                .padding(horizontal = 34.dp, vertical = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(18.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            pinned.forEachIndexed { index, app ->
                NameTile(
                    name = app.label,
                    onClick = { onLaunch(app) },
                    modifier = Modifier.weight(1f),
                    focusRequester = if (index == 0) firstFocus else null,
                )
            }
            // Fehlende Apps freilassen, damit "Alle Apps" immer gleich groß bleibt
            repeat((PINNED_KEYS.size - pinned.size).coerceAtLeast(0)) {
                Spacer(Modifier.weight(1f))
            }
            NameTile(
                name = "Alle Apps",
                onClick = onAllApps,
                modifier = Modifier.weight(1f),
                focusRequester = if (pinned.isEmpty()) firstFocus else null,
            )
        }
    }
}

@Composable
private fun AllAppsScreen(
    apps: List<AppEntry>,
    onLaunch: (AppEntry) -> Unit,
    onBack: () -> Unit,
    onSettings: () -> Unit,
) {
    val firstFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(150)
        runCatching { firstFocus.requestFocus() }
    }

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 40.dp, vertical = 32.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 8.dp)) {
            Text(text = "Alle Apps", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.weight(1f))
            ChipButton(text = "Zurück", onClick = onBack)
        }
        Spacer(Modifier.height(16.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(5),
            horizontalArrangement = Arrangement.spacedBy(18.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
            // Rand, damit vergrößerte Kacheln nicht abgeschnitten werden
            contentPadding = PaddingValues(12.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            // Einstellungen immer an erster Stelle
            item {
                NameTile(
                    name = "Einstellungen",
                    onClick = onSettings,
                    focusRequester = firstFocus,
                    highlight = true,
                )
            }
            items(apps, key = { it.packageName }) { app ->
                NameTile(name = app.label, onClick = { onLaunch(app) })
            }
        }
    }
}

@Composable
fun ChipButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Surface(
        onClick = onClick,
        modifier = modifier,
        shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(14.dp)),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1.04f),
        colors = ClickableSurfaceDefaults.colors(
            containerColor = Color(0x33FFFFFF),
            contentColor = Color.White,
            focusedContainerColor = Color(0xF2FFFFFF),
            focusedContentColor = Color(0xFF1C1C1E),
        ),
    ) {
        Text(
            text = text,
            fontSize = 18.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
        )
    }
}

/** Kachel mit App-Namen (statt Symbol). Beim Fokus: hell mit dunkler Schrift. */
@Composable
fun NameTile(
    name: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    focusRequester: FocusRequester? = null,
    highlight: Boolean = false,
    singleLine: Boolean = false,
) {
    val focusMod = if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier
    Surface(
        onClick = onClick,
        modifier = modifier.fillMaxWidth().height(92.dp).then(focusMod),
        shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(18.dp)),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1.07f),
        colors = ClickableSurfaceDefaults.colors(
            containerColor = if (highlight) Color(0x66FFFFFF) else Color(0x40000000),
            contentColor = Color.White,
            focusedContainerColor = Color(0xF2FFFFFF),
            focusedContentColor = Color(0xFF1C1C1E),
        ),
    ) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(
                text = name,
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = if (singleLine) 1 else 2,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 10.dp),
            )
        }
    }
}

private val GERMAN = Locale.GERMANY

/** Uhr, die die Zeit selbst liest – nur sie wird jede Sekunde neu gezeichnet. */
@Composable
fun LiveClock(nowState: State<LocalDateTime>, style: String, modifier: Modifier = Modifier) {
    Clock(now = nowState.value, style = style, modifier = modifier)
}

/** Große Uhr in verschiedenen Stilen. Zeigt die echte Uhrzeit. */
@Composable
fun Clock(now: LocalDateTime, style: String, modifier: Modifier = Modifier) {
    val fg = LocalFg.current
    if (style == "analog") {
        AnalogClock(now = now, color = fg, modifier = modifier.size(250.dp))
        return
    }
    val (weight, size, pattern) = when (style) {
        "mittel" -> Triple(FontWeight.Medium, 160, "H:mm")
        "duenn" -> Triple(FontWeight.Thin, 180, "H:mm")
        "sekunden" -> Triple(FontWeight.Bold, 120, "H:mm:ss")
        else -> Triple(FontWeight.Black, 150, "H:mm")   // fett, fett_datum
    }
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = DateTimeFormatter.ofPattern(pattern).format(now),
            color = fg,
            fontSize = size.sp,
            fontWeight = weight,
            letterSpacing = (-3).sp,
            maxLines = 1,
            style = TextStyle(shadow = Shadow(color = Color(0x33000000), blurRadius = 24f)),
        )
        if (style == "fett_datum") {
            Text(
                text = DateTimeFormatter.ofPattern("EEEE, d. MMMM", GERMAN).format(now),
                color = fg,
                fontSize = 28.sp,
                fontWeight = FontWeight.SemiBold,
                style = TextStyle(shadow = Shadow(color = Color(0x33000000), blurRadius = 16f)),
            )
        }
    }
}

@Composable
private fun AnalogClock(now: LocalDateTime, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val c = Offset(size.width / 2, size.height / 2)
        val r = size.minDimension / 2
        drawCircle(Color(0x33000000), radius = r, center = c)
        drawCircle(color.copy(alpha = 0.6f), radius = r, center = c, style = Stroke(width = r * 0.025f))
        for (k in 0 until 12) {
            rotate(k * 30f, c) {
                drawLine(
                    color = color,
                    start = Offset(c.x, c.y - r * 0.92f),
                    end = Offset(c.x, c.y - r * (if (k % 3 == 0) 0.76f else 0.84f)),
                    strokeWidth = r * (if (k % 3 == 0) 0.04f else 0.022f),
                    cap = StrokeCap.Round,
                )
            }
        }
        val minutes = now.minute + now.second / 60f
        val hours = (now.hour % 12) + minutes / 60f
        rotate(hours * 30f, c) {
            drawLine(color, c, Offset(c.x, c.y - r * 0.5f), strokeWidth = r * 0.06f, cap = StrokeCap.Round)
        }
        rotate(minutes * 6f, c) {
            drawLine(color, c, Offset(c.x, c.y - r * 0.75f), strokeWidth = r * 0.04f, cap = StrokeCap.Round)
        }
        rotate(now.second * 6f, c) {
            drawLine(Color(0xFFFF9F0A), Offset(c.x, c.y + r * 0.12f), Offset(c.x, c.y - r * 0.82f), strokeWidth = r * 0.015f, cap = StrokeCap.Round)
        }
        drawCircle(Color(0xFFFF9F0A), radius = r * 0.035f, center = c)
    }
}
