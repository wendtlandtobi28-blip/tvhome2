# TvHome – eigener Launcher für den Fire TV Stick Lite

Ruhiger, dunkler Home-Bildschirm mit einer Reihe aus App-Kacheln, Fokus-Vergrößerung, App-Name und Uhr. Zeigt nur installierte Apps an.

## 1. APK bauen
1. Android Studio installieren und den Ordner `TvHome` öffnen.
2. Warten, bis Gradle synchronisiert hat (die Versionen in `build.gradle.kts` kann Android Studio bei Bedarf aktualisieren).
3. Menü **Build → Build APK(s)**. Die Datei liegt danach unter `app/build/outputs/apk/debug/app-debug.apk`.

## 2. Auf den Stick installieren
1. Auf dem Fire TV: **Einstellungen → Mein Fire TV → Optionen für Entwickler** → *ADB-Debugging* und *Apps unbekannter Herkunft* einschalten. (Falls „Optionen für Entwickler" fehlt: unter *Info* siebenmal auf den Gerätenamen klicken.)
2. IP-Adresse des Sticks unter **Einstellungen → Mein Fire TV → Info → Netzwerk** nachsehen.
3. Am Computer:
   ```
   adb connect <IP-ADRESSE>:5555
   adb install app-debug.apk
   ```
4. Auf dem Stick im Bereich **Einstellungen → Anwendungen → Alle installierten Anwendungen verwalten** erscheint „TvHome" und lässt sich von dort starten.

## 3. Mit der Home-Taste öffnen
Fire OS erlaubt keinen anderen Standard-Launcher ohne Eingriff ins System. Mit einer Tasten-Umbelegungs-App (z. B. „Button Mapper") kann die Home-Taste so belegt werden, dass sie TvHome startet. Das ist optional und funktioniert ohne Root.

## Hinweis
Das Design ist ein eigenes, von Apple TV inspiriertes Layout. Es enthält keine Apple-Logos oder -Icons.
