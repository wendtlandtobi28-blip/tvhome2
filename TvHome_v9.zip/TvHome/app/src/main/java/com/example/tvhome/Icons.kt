package com.example.tvhome

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp

/*
 * Moderne, animierte Symbole für die Infos rechts.
 * Alles selbst gezeichnet, keine fremden Bilder.
 */

private val White = Color.White
private val Dim = Color(0x40FFFFFF)
private val SunYellow = Color(0xFFFFD25A)
private val BoltYellow = Color(0xFFFFE066)

/** Läuft endlos von 0 bis 1. */
@Composable
private fun loop(durationMs: Int): Float {
    val transition = rememberInfiniteTransition(label = "loop")
    val t by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(durationMs, easing = LinearEasing), RepeatMode.Restart),
        label = "t",
    )
    return t
}

/**
 * Sichtbarkeit von Bogen [i] (1..3) in der Wellen-Animation:
 * erst der Punkt, dann ein Bogen nach dem anderen, kurz halten, sanft ausblenden.
 */
private fun waveAlpha(t: Float, i: Int): Float {
    val appear = 0.12f + 0.16f * (i - 1)          // Zeitpunkt, an dem Bogen i erscheint
    val fadeIn = ((t - appear) / 0.12f).coerceIn(0f, 1f)
    val fadeOut = if (t > 0.82f) ((1f - t) / 0.18f).coerceIn(0f, 1f) else 1f
    return fadeIn * fadeOut
}

/** Bogen, der von etwas kleiner auf volle Größe wächst, während er erscheint. */
private fun DrawScope.growingArc(
    center: Offset,
    radius: Float,
    progress: Float,
    startAngle: Float,
    color: Color,
    stroke: Float,
) {
    val r = radius * (0.75f + 0.25f * progress)
    drawArc(
        color = color,
        startAngle = startAngle,
        sweepAngle = 90f,
        useCenter = false,
        topLeft = Offset(center.x - r, center.y - r),
        size = Size(r * 2, r * 2),
        style = Stroke(width = stroke, cap = StrokeCap.Round),
    )
}

/** Ton/Bluetooth: Punkt, dann drei Bögen nach rechts – von klein nach groß. */
@Composable
fun SoundIcon(connected: Boolean) {
    val t = loop(2200)
    Canvas(Modifier.size(28.dp)) {
        val w = size.width
        val stroke = w * 0.095f
        val c = Offset(w * 0.16f, size.height / 2f)
        drawCircle(if (connected) White else Dim, radius = stroke * 0.85f, center = c)
        for (i in 1..3) {
            val radius = w * 0.24f * i
            if (connected) {
                // blasser Umriss bleibt immer stehen, der helle Bogen wächst darüber
                growingArc(c, radius, 1f, -45f, Dim, stroke)
                val a = waveAlpha(t, i)
                if (a > 0f) growingArc(c, radius, a, -45f, White.copy(alpha = a), stroke)
            } else {
                growingArc(c, radius, 1f, -45f, Dim, stroke)
            }
        }
    }
}

/** WLAN: Punkt unten, Bögen bauen sich von unten nach oben auf, bis zur Signalstärke. */
@Composable
fun WifiIcon(level: Int) {
    val t = loop(2400)
    Canvas(Modifier.size(30.dp)) {
        val w = size.width
        val h = size.height
        val stroke = w * 0.09f
        val c = Offset(w / 2f, h * 0.86f)
        drawCircle(if (level > 0) White else Dim, radius = stroke * 0.9f, center = c)
        for (i in 1..3) {
            val radius = h * 0.24f * i
            growingArc(c, radius, 1f, -135f, Dim, stroke)
            if (i <= level) {
                // Balken bis zur Signalstärke bleiben halb hell, die Welle läuft von unten nach oben drüber
                growingArc(c, radius, 1f, -135f, White.copy(alpha = 0.55f), stroke)
                val a = waveAlpha(t, i)
                if (a > 0f) growingArc(c, radius, a, -135f, White.copy(alpha = a), stroke)
            }
        }
    }
}

/** Wetter passend zum Open-Meteo-Code, leicht animiert. */
@Composable
fun WeatherIcon(code: Int) {
    val t = loop(12_000)   // langsam für Sonnenstrahlen
    val fast = loop(1200)  // schneller für Regen/Schnee
    Canvas(Modifier.size(32.dp)) {
        when (code) {
            0 -> sun(Offset(size.width / 2, size.height / 2), size.width * 0.2f, t)
            1, 2 -> {
                sun(Offset(size.width * 0.38f, size.height * 0.36f), size.width * 0.15f, t)
                cloud(Offset(size.width * 0.58f, size.height * 0.64f), size.width * 0.8f)
            }
            45, 48 -> fog(fast)
            in 51..67, in 80..82 -> {
                cloud(Offset(size.width / 2, size.height * 0.4f), size.width)
                rain(fast)
            }
            in 71..77, 85, 86 -> {
                cloud(Offset(size.width / 2, size.height * 0.4f), size.width)
                snow(fast)
            }
            in 95..99 -> {
                cloud(Offset(size.width / 2, size.height * 0.4f), size.width)
                bolt(fast)
            }
            else -> cloud(Offset(size.width / 2, size.height / 2), size.width)
        }
    }
}

private fun DrawScope.sun(c: Offset, r: Float, t: Float) {
    drawCircle(SunYellow, radius = r, center = c)
    rotate(degrees = t * 360f, pivot = c) {
        for (k in 0 until 8) {
            rotate(degrees = k * 45f, pivot = c) {
                drawLine(
                    color = SunYellow,
                    start = Offset(c.x, c.y - r * 1.45f),
                    end = Offset(c.x, c.y - r * 1.95f),
                    strokeWidth = r * 0.28f,
                    cap = StrokeCap.Round,
                )
            }
        }
    }
}

/** Wolke aus drei Kreisen und einem abgerundeten Boden. */
private fun DrawScope.cloud(c: Offset, w: Float) {
    val u = w / 10f
    drawCircle(White, radius = u * 2.0f, center = Offset(c.x - u * 1.9f, c.y + u * 0.3f))
    drawCircle(White, radius = u * 2.7f, center = Offset(c.x + u * 0.2f, c.y - u * 0.6f))
    drawCircle(White, radius = u * 1.9f, center = Offset(c.x + u * 2.4f, c.y + u * 0.4f))
    drawRoundRect(
        color = White,
        topLeft = Offset(c.x - u * 3.9f, c.y + u * 0.3f),
        size = Size(u * 8.2f, u * 2.0f),
        cornerRadius = CornerRadius(u, u),
    )
}

private fun DrawScope.rain(t: Float) {
    val u = size.width / 10f
    for (k in 0 until 3) {
        val x = size.width * (0.3f + 0.2f * k)
        val phase = (t + k * 0.33f) % 1f
        val y = size.height * 0.68f + phase * u * 2.6f
        drawLine(
            color = Color(0xFF9ED0FF).copy(alpha = 1f - phase),
            start = Offset(x, y),
            end = Offset(x - u * 0.4f, y + u * 1.2f),
            strokeWidth = u * 0.6f,
            cap = StrokeCap.Round,
        )
    }
}

private fun DrawScope.snow(t: Float) {
    val u = size.width / 10f
    for (k in 0 until 3) {
        val x = size.width * (0.3f + 0.2f * k)
        val phase = (t + k * 0.33f) % 1f
        drawCircle(
            color = White.copy(alpha = 1f - phase),
            radius = u * 0.55f,
            center = Offset(x, size.height * 0.7f + phase * u * 2.6f),
        )
    }
}

private fun DrawScope.bolt(t: Float) {
    val flash = if (t < 0.15f || t in 0.25f..0.32f) 1f else 0.55f
    val p = Path().apply {
        moveTo(size.width * 0.55f, size.height * 0.6f)
        lineTo(size.width * 0.4f, size.height * 0.82f)
        lineTo(size.width * 0.52f, size.height * 0.82f)
        lineTo(size.width * 0.44f, size.height * 1.0f)
        lineTo(size.width * 0.66f, size.height * 0.74f)
        lineTo(size.width * 0.54f, size.height * 0.74f)
        close()
    }
    drawPath(p, BoltYellow.copy(alpha = flash))
}

private fun DrawScope.fog(t: Float) {
    val u = size.width / 10f
    for (k in 0 until 3) {
        val shift = kotlin.math.sin((t + k * 0.3f) * 2 * Math.PI).toFloat() * u * 0.8f
        val y = size.height * (0.3f + 0.2f * k)
        drawLine(
            color = White.copy(alpha = 0.9f - 0.2f * k),
            start = Offset(size.width * 0.15f + shift, y),
            end = Offset(size.width * 0.85f + shift, y),
            strokeWidth = u * 0.7f,
            cap = StrokeCap.Round,
        )
    }
}
