package com.example.tvhome

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper

/**
 * Läuft im Hintergrund und holt TV Home zurück nach vorne:
 *  - nach dem Hochfahren und nach Updates
 *  - sobald Amazons Startseite vorne ist (nach Home-Taste oder wenn man eine App verlässt)
 */
class HomeWatchService : Service() {

    companion object {
        const val REASON_BOOT = "boot"
        const val REASON_UPDATE = "update"
        const val REASON_APP = "app"
        private const val EXTRA_REASON = "reason"
        private const val CHANNEL = "tvhome_watch"

        /** Was zuletzt vorne war (für die Anzeige in den Einstellungen) */
        @Volatile
        var lastTopPackage: String = "–"

        /** Wurde Amazons Startseite schon einmal erkannt? */
        @Volatile
        var homeDetected = false

        fun start(context: Context, reason: String = REASON_APP) {
            val i = Intent(context, HomeWatchService::class.java).putExtra(EXTRA_REASON, reason)
            runCatching {
                if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i) else context.startService(i)
            }
        }

        /** Darf der Launcher zurückkommen? (Einstellungen → Bildschirm) */
        fun autoReturnOn(context: Context): Boolean =
            context.getSharedPreferences("tvhome", Context.MODE_PRIVATE).getBoolean("auto_return", true)
    }

    private val bootHandler = Handler(Looper.getMainLooper())
    private val pollHandler = Handler(Looper.getMainLooper())
    private val activityManager by lazy { getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager }

    /** Die Startseiten-Activities (Paket/Klasse) von Amazon & Co., nicht unsere eigene */
    private val homeComponents: Set<String> by lazy {
        runCatching {
            packageManager.queryIntentActivities(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0
            ).map { it.activityInfo.packageName + "/" + it.activityInfo.name }
        }.getOrDefault(emptyList())
            .filter { !it.startsWith("$packageName/") && !it.contains("settings", ignoreCase = true) }
            .toSet()
    }

    /**
     * Ist das gerade Amazons Startseite? Nur die Startseite selbst zählt –
     * Einstellungen, Suche usw. bleiben in Ruhe, auch wenn sie zum selben Paket gehören.
     */
    private fun isHomeScreen(pkg: String, cls: String): Boolean {
        if ("$pkg/$cls" in homeComponents) return true
        return pkg == "com.amazon.tv.launcher" &&
            cls.contains("home", ignoreCase = true) &&
            !cls.contains("settings", ignoreCase = true)
    }

    private var homeSeen = 0
    private var lastReturn = 0L

    /** Prüft alle 0,7 Sekunden, welche App vorne ist. */
    private val poll = object : Runnable {
        override fun run() {
            checkForeground()
            pollHandler.postDelayed(this, 700)
        }
    }

    private fun checkForeground() {
        val top = runCatching {
            @Suppress("DEPRECATION")
            activityManager.getRunningTasks(1).firstOrNull()?.topActivity
        }.getOrNull()
        lastTopPackage = top?.packageName ?: "nicht erkennbar"
        if (top != null && isHomeScreen(top.packageName, top.className)) {
            homeDetected = true
            homeSeen++
            val now = System.currentTimeMillis()
            // Zweimal hintereinander gesehen (ca. 1 Sekunde) -> zurückholen, höchstens alle 3 Sekunden
            if (homeSeen >= 2 && now - lastReturn > 3_000 && autoReturnOn(this)) {
                lastReturn = now
                homeSeen = 0
                bringToFront()
            }
        } else {
            homeSeen = 0
        }
    }

    /** Zusätzlich: falls Fire OS das Home-Tasten-Signal doch schickt */
    private val homeKeyReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.getStringExtra("reason") != "homekey") return
            if (!autoReturnOn(context)) return
            bootHandler.postDelayed({ bringToFront() }, 1_200)
        }
    }

    override fun onCreate() {
        super.onCreate()
        startForeground(1, buildNotification())
        runCatching { registerReceiver(homeKeyReceiver, IntentFilter(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)) }
        pollHandler.post(poll)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.getStringExtra(EXTRA_REASON)) {
            REASON_BOOT -> {
                // Sofort und danach noch ein paar Mal, weil Amazon seinen Startbildschirm teils später öffnet.
                bringToFront()
                bootHandler.postDelayed({ bringToFrontIfIdle() }, 3_000)
                bootHandler.postDelayed({ bringToFrontIfIdle() }, 7_000)
                bootHandler.postDelayed({ bringToFrontIfIdle() }, 12_000)
            }
            REASON_UPDATE -> bootHandler.postDelayed({ bringToFront() }, 500)
        }
        return START_STICKY
    }

    /** Nur nachholen, wenn man nicht gerade eine App gestartet oder im Launcher etwas gedrückt hat */
    private fun bringToFrontIfIdle() {
        val now = System.currentTimeMillis()
        if (now - MainActivity.lastAppLaunch > 15_000 && now - MainActivity.lastInteraction > 4_000) bringToFront()
    }

    private fun bringToFront() {
        runCatching {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or
                            Intent.FLAG_ACTIVITY_NO_ANIMATION
                    )
                    .putExtra(MainActivity.EXTRA_GO_HOME, true)
            )
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "TV Home im Hintergrund", NotificationManager.IMPORTANCE_MIN)
            )
            Notification.Builder(this, CHANNEL)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        return builder
            .setContentTitle("TV Home von Tobi")
            .setContentText("Hält den Launcher bereit")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(homeKeyReceiver) }
        bootHandler.removeCallbacksAndMessages(null)
        pollHandler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
