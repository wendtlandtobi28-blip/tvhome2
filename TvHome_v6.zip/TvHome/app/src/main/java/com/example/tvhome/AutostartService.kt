package com.example.tvhome

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent

/**
 * Bedienungshilfe nur für den Autostart.
 * Einschalten: Fire TV Einstellungen → Bedienungshilfen → TV Home von Tobi.
 * Das System startet diesen Dienst nach jedem Hochfahren, und Bedienungshilfen
 * dürfen Apps starten – dafür ist kein ADB nötig.
 */
class AutostartService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        val justBooted = SystemClock.elapsedRealtime() < 5 * 60_000L
        val justUpdated = runCatching {
            System.currentTimeMillis() - packageManager.getPackageInfo(packageName, 0).lastUpdateTime < 2 * 60_000L
        }.getOrDefault(false)
        if (!justBooted && !justUpdated) return

        // Kurz warten, damit der Amazon-Startbildschirm uns nicht wieder überdeckt
        Handler(Looper.getMainLooper()).postDelayed({
            runCatching {
                startActivity(
                    Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }, if (justBooted) 6_000L else 1_000L)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}
}
