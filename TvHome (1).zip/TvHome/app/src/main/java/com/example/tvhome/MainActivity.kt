@file:OptIn(ExperimentalTvMaterial3Api::class)

package com.example.tvhome

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.ExperimentalTvMaterial3Api
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Surface
import androidx.tv.material3.Text
import androidx.tv.material3.darkColorScheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.Locale

data class AppEntry(
    val label: String,
    val packageName: String,
    val icon: ImageBitmap,
)

class MainActivity : ComponentActivity() {

    // Wird bei jedem Zurückkehren erhöht, damit neu installierte Apps erscheinen
    private var refresh by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val apps by produceState(emptyList<AppEntry>(), refresh) {
                value = withContext(Dispatchers.IO) { loadApps() }
            }
            // Als Home-Bildschirm soll "Zurück" nichts tun
            BackHandler { }
            MaterialTheme(colorScheme = darkColorScheme()) {
                HomeScreen(apps = apps, onLaunch = ::launch)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refresh++
    }

    private fun loadApps(): List<AppEntry> {
        val pm = packageManager
        val leanback = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val normal = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return (pm.queryIntentActivities(leanback, 0) + pm.queryIntentActivities(normal, 0))
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .map {
                AppEntry(
                    label = it.loadLabel(pm).toString(),
                    packageName = it.activityInfo.packageName,
                    icon = it.loadIcon(pm).toBitmap(192, 192).asImageBitmap(),
                )
            }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
    }

    private fun launch(app: AppEntry) {
        val pm: PackageManager = packageManager
        val intent = pm.getLeanbackLaunchIntentForPackage(app.packageName)
            ?: pm.getLaunchIntentForPackage(app.packageName)
            ?: return
        runCatching { startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }
}

@Composable
fun HomeScreen(apps: List<AppEntry>, onLaunch: (AppEntry) -> Unit) {
    var focusedApp by remember { mutableStateOf<AppEntry?>(null) }
    val firstTile = remember { FocusRequester() }

    // Beim Start sofort den ersten Eintrag fokussieren
    LaunchedEffect(apps) {
        if (apps.isNotEmpty()) {
            delay(150)
            runCatching { firstTile.requestFocus() }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(listOf(Color(0xFF0B0B10), Color(0xFF1E1E2A)))
            )
    ) {
        Clock(Modifier.align(Alignment.TopEnd).padding(top = 32.dp, end = 48.dp))

        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(bottom = 48.dp)
        ) {
            Text(
                text = focusedApp?.label.orEmpty(),
                color = Color.White,
                fontSize = 30.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                modifier = Modifier.padding(start = 48.dp).height(44.dp),
            )
            Spacer(Modifier.height(12.dp))
            LazyRow(
                contentPadding = PaddingValues(horizontal = 40.dp, vertical = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(20.dp),
            ) {
                items(apps, key = { it.packageName }) { app ->
                    val isFirst = app == apps.first()
                    AppTile(
                        app = app,
                        onFocus = { focusedApp = app },
                        onClick = { onLaunch(app) },
                        modifier = if (isFirst) Modifier.focusRequester(firstTile) else Modifier,
                    )
                }
            }
        }
    }
}

@Composable
private fun AppTile(
    app: AppEntry,
    onFocus: () -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        onClick = onClick,
        modifier = modifier
            .size(112.dp)
            .onFocusChanged { if (it.isFocused) onFocus() },
        shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(20.dp)),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1.18f),
        colors = ClickableSurfaceDefaults.colors(
            containerColor = Color(0x1AFFFFFF),
            focusedContainerColor = Color(0x33FFFFFF),
        ),
    ) {
        Image(
            bitmap = app.icon,
            contentDescription = app.label,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
        )
    }
}

@Composable
private fun Clock(modifier: Modifier = Modifier) {
    val now by produceState(LocalDateTime.now()) {
        while (true) {
            value = LocalDateTime.now()
            delay(15_000)
        }
    }
    val time = DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT).format(now)
    val date = DateTimeFormatter.ofPattern("EEEE, d. MMMM", Locale.getDefault()).format(now)

    Column(modifier = modifier, horizontalAlignment = Alignment.End) {
        Text(text = time, color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Light)
        Text(text = date, color = Color(0xB3FFFFFF), fontSize = 16.sp)
    }
}
