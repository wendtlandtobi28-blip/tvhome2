package com.example.tvhome

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.provider.Settings

/**
 * Startet TvHome nach dem Hochfahren des Sticks.
 * Funktioniert nur, wenn die Berechtigung "Über anderen Apps anzeigen" erteilt ist
 * (Android erlaubt sonst keinen Start aus dem Hintergrund).
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED &&
            intent.action != Intent.ACTION_MY_PACKAGE_REPLACED
        ) return
        val delayMs = if (intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) 1_000L else 8_000L
        if (!Settings.canDrawOverlays(context)) return

        val pending = goAsync()
        // Kurz warten, damit der normale Fire-TV-Startbildschirm uns nicht überdeckt
        Handler(Looper.getMainLooper()).postDelayed({
            runCatching {
                context.startActivity(
                    Intent(context, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
            pending.finish()
        }, delayMs)
    }
}
