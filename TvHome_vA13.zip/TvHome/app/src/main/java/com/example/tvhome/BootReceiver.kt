package com.example.tvhome

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings

/**
 * Startet TV Home nach dem Hochfahren des Sticks und nach Updates.
 * Fire OS 7 (Android 9) erlaubt das ohne Sonderrecht.
 * Ab Android 10 braucht es "Über anderen Apps anzeigen" oder die Bedienungshilfe.
 */
class BootReceiver : BroadcastReceiver() {
    companion object {
        /** Damit die beiden Startsignale den Launcher nicht doppelt starten */
        @Volatile
        private var bootSequenceAt = 0L
    }

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action != Intent.ACTION_BOOT_COMPLETED &&
            action != Intent.ACTION_LOCKED_BOOT_COMPLETED &&
            action != Intent.ACTION_MY_PACKAGE_REPLACED
        ) return
        if (Build.VERSION.SDK_INT >= 29 && !Settings.canDrawOverlays(context)) return

        if (action != Intent.ACTION_MY_PACKAGE_REPLACED) {
            val nowMs = System.currentTimeMillis()
            if (nowMs - bootSequenceAt < 20_000) return
            bootSequenceAt = nowMs
        }

        val app = context.applicationContext
        val pending = goAsync()
        val handler = Handler(Looper.getMainLooper())
        val start = Runnable {
            runCatching {
                app.startActivity(
                    Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }
        if (action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            handler.postDelayed({ start.run(); pending.finish() }, 500)
        } else {
            // Sofort starten, dann noch zweimal nach vorne holen,
            // falls sich der Amazon-Startbildschirm danach darüber legt.
            // Hat man in der Zwischenzeit schon eine App (z. B. Netflix) gestartet, nicht wieder rausreißen
            val refront = Runnable {
                if (System.currentTimeMillis() - MainActivity.lastAppLaunch > 15_000) start.run()
            }
            start.run()
            handler.postDelayed(refront, 2_500)
            handler.postDelayed({ refront.run(); pending.finish() }, 6_000)
        }
    }
}
