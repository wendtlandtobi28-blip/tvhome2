package com.example.tvhome

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings

/**
 * Startet TV Home nach dem Hochfahren des Sticks und nach Updates.
 * Fire OS 7 (Android 9) erlaubt das ohne Sonderrecht.
 * Ab Android 10 braucht es "Über anderen Apps anzeigen" oder die Bedienungshilfe.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action != Intent.ACTION_BOOT_COMPLETED && action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        if (Build.VERSION.SDK_INT >= 29 && !Settings.canDrawOverlays(context)) return

        val app = context.applicationContext
        val pending = goAsync()
        val handler = Handler(Looper.getMainLooper())
        val start = Runnable {
            runCatching {
                app.startActivity(
                    Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }
        if (action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            handler.postDelayed({ start.run(); pending.finish() }, 1_000)
        } else {
            // Nach 6 Sekunden starten, nach 9 Sekunden nochmal nach vorne holen,
            // falls der Amazon-Startbildschirm sich danach noch darüber gelegt hat.
            handler.postDelayed(start, 6_000)
            handler.postDelayed({ start.run(); pending.finish() }, 9_000)
        }
    }
}
